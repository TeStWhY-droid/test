#!/bin/bash
# Quick Fix for Kali Linux externally-managed-environment

echo "🔧 Ryoiki Tenkai - Quick Fix for Kali Linux"
echo "==========================================="
echo ""

# Create venv
echo "[1/4] Creating virtual environment..."
python3 -m venv venv 2>/dev/null || {
    echo "Installing python3-venv..."
    sudo apt install -y python3-venv
    python3 -m venv venv
}

# Activate and install
echo "[2/4] Installing dependencies..."
source venv/bin/activate
pip install --quiet --upgrade pip
pip install --quiet rich requests

# Create wrapper scripts
echo "[3/4] Creating launcher scripts..."

cat > ryoiki << 'EOF'
#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source "$DIR/venv/bin/activate"
python "$DIR/ryoiki_tenkai_pro.py" "$@"
EOF

cat > ryoiki-ui << 'EOF'
#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source "$DIR/venv/bin/activate"
python "$DIR/ryoiki_tenkai_ultimate.py" "$@"
EOF

chmod +x ryoiki ryoiki-ui ryoiki_tenkai_pro.py ryoiki_tenkai_ultimate.py

echo "[4/4] Done!"
echo ""
echo "✅ Fixed! You can now run:"
echo "   ./ryoiki       (Professional version)"
echo "   ./ryoiki-ui    (Ultimate UI version)"
echo ""
echo "Or activate venv manually:"
echo "   source venv/bin/activate"
echo "   python ryoiki_tenkai_pro.py"
echo ""
