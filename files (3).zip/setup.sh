#!/bin/bash

# Ryoiki Tenkai - Professional Setup Script
# Automated installation for Kali Linux

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${CYAN}"
cat << "EOF"
    ██████╗ ██╗   ██╗ ██████╗ ██╗██╗  ██╗██╗
    ██╔══██╗╚██╗ ██╔╝██╔═══██╗██║██║ ██╔╝██║
    ██████╔╝ ╚████╔╝ ██║   ██║██║█████╔╝ ██║
    ██╔══██╗  ╚██╔╝  ██║   ██║██║██╔═██╗ ██║
    ██║  ██║   ██║   ╚██████╔╝██║██║  ██╗██║
    ╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚═╝╚═╝  ╚═╝╚═╝
    
    Setup Script - Automated Installation
EOF
echo -e "${NC}"

echo -e "${GREEN}[*] Starting Ryoiki Tenkai installation...${NC}\n"

# Check if running on Kali
if ! grep -q "Kali" /etc/os-release 2>/dev/null; then
    echo -e "${YELLOW}[!] Warning: This script is designed for Kali Linux${NC}"
    read -p "Continue anyway? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Check Python version
echo -e "${CYAN}[*] Checking Python version...${NC}"
python_version=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1,2)
required_version="3.8"

if [ "$(printf '%s\n' "$required_version" "$python_version" | sort -V | head -n1)" != "$required_version" ]; then 
    echo -e "${RED}[!] Python 3.8+ required. Found: $python_version${NC}"
    exit 1
fi
echo -e "${GREEN}[✓] Python $python_version${NC}"

# Create virtual environment for Kali Linux compatibility
echo -e "\n${CYAN}[*] Setting up Python virtual environment...${NC}"

# Check if venv exists
if [ ! -d "venv" ]; then
    echo -e "${CYAN}[*] Creating virtual environment...${NC}"
    python3 -m venv venv
    
    if [ $? -ne 0 ]; then
        echo -e "${YELLOW}[!] venv module not found, installing...${NC}"
        sudo apt install -y python3-venv
        python3 -m venv venv
    fi
    
    echo -e "${GREEN}[✓] Virtual environment created${NC}"
else
    echo -e "${GREEN}[✓] Virtual environment already exists${NC}"
fi

# Activate virtual environment and install dependencies
echo -e "\n${CYAN}[*] Installing Python dependencies in venv...${NC}"
source venv/bin/activate
pip install --quiet --upgrade pip
pip install --quiet rich requests

if [ $? -eq 0 ]; then
    echo -e "${GREEN}[✓] Python dependencies installed${NC}"
else
    echo -e "${RED}[!] Failed to install Python dependencies${NC}"
    exit 1
fi

# Check for Ollama
echo -e "\n${CYAN}[*] Checking for Ollama...${NC}"
if command -v ollama &> /dev/null; then
    echo -e "${GREEN}[✓] Ollama found${NC}"
else
    echo -e "${YELLOW}[!] Ollama not found${NC}"
    read -p "Install Ollama? (Y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Nn]$ ]]; then
        echo -e "${CYAN}[*] Installing Ollama...${NC}"
        curl -fsSL https://ollama.ai/install.sh | sh
        echo -e "${GREEN}[✓] Ollama installed${NC}"
    fi
fi

# Start Ollama service
echo -e "\n${CYAN}[*] Starting Ollama service...${NC}"
if pgrep -x "ollama" > /dev/null; then
    echo -e "${GREEN}[✓] Ollama already running${NC}"
else
    ollama serve > /dev/null 2>&1 &
    sleep 2
    echo -e "${GREEN}[✓] Ollama service started${NC}"
fi

# Download model
echo -e "\n${CYAN}[*] Checking for Qwen3 model...${NC}"
if ollama list | grep -q "ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q5_K_M"; then
    echo -e "${GREEN}[✓] Model already downloaded${NC}"
else
    echo -e "${YELLOW}[!] Downloading model (this may take a while)...${NC}"
    echo -e "${CYAN}Recommended model: ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q5_K_M${NC}"
    echo -e "${CYAN}This is a quantized 4B model optimized for penetration testing${NC}"
    echo ""
    
    model="ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q5_K_M"
    
    echo -e "${CYAN}[*] Downloading $model...${NC}"
    ollama pull $model
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}[✓] Model downloaded${NC}"
    else
        echo -e "${RED}[!] Failed to download model${NC}"
        exit 1
    fi
fi

# Make script executable
echo -e "\n${CYAN}[*] Setting up launcher scripts...${NC}"

# Create wrapper script for professional version
cat > ryoiki << 'EOF'
#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source "$DIR/venv/bin/activate"
python "$DIR/ryoiki_tenkai_pro.py" "$@"
EOF
chmod +x ryoiki

# Create wrapper script for ultimate version
cat > ryoiki-ui << 'EOF'
#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source "$DIR/venv/bin/activate"
python "$DIR/ryoiki_tenkai_ultimate.py" "$@"
EOF
chmod +x ryoiki-ui

# Make original scripts executable
chmod +x ryoiki_tenkai_pro.py ryoiki_tenkai_ultimate.py

echo -e "${GREEN}[✓] Launcher scripts created${NC}"

# Optional: Create symlink
echo -e "\n${CYAN}[*] Create system-wide symlinks?${NC}"
echo -e "${DIM}This allows running 'ryoiki' from anywhere (requires sudo)${NC}"
read -p "(y/N) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    sudo ln -sf "$(pwd)/ryoiki" /usr/local/bin/ryoiki
    sudo ln -sf "$(pwd)/ryoiki-ui" /usr/local/bin/ryoiki-ui
    echo -e "${GREEN}[✓] Symlinks created:${NC}"
    echo -e "${GREEN}    - /usr/local/bin/ryoiki (professional version)${NC}"
    echo -e "${GREEN}    - /usr/local/bin/ryoiki-ui (ultimate UI version)${NC}"
fi

# Verify Kali tools
echo -e "\n${CYAN}[*] Verifying Kali tools...${NC}"
missing_tools=()
critical_tools=("nmap" "gobuster" "nikto" "sqlmap" "hydra")

for tool in "${critical_tools[@]}"; do
    if ! command -v $tool &> /dev/null; then
        missing_tools+=("$tool")
    fi
done

if [ ${#missing_tools[@]} -eq 0 ]; then
    echo -e "${GREEN}[✓] All critical tools found${NC}"
else
    echo -e "${YELLOW}[!] Missing tools: ${missing_tools[*]}${NC}"
    read -p "Install missing tools? (Y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Nn]$ ]]; then
        sudo apt update
        sudo apt install -y "${missing_tools[@]}"
    fi
fi

# Create workspace directory
echo -e "\n${CYAN}[*] Creating workspace...${NC}"
mkdir -p engagements workspace
echo -e "${GREEN}[✓] Workspace created${NC}"

# Final summary
echo -e "\n${GREEN}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                                                       ║${NC}"
echo -e "${GREEN}║  ✓  Installation Complete!                           ║${NC}"
echo -e "${GREEN}║                                                       ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════╝${NC}"

echo -e "\n${CYAN}Quick Start:${NC}"
echo -e "  ${YELLOW}Professional Version (Standard UI):${NC}"
echo -e "    ./ryoiki"
if [[ -L /usr/local/bin/ryoiki ]]; then
    echo -e "    ${GREEN}or simply: ${YELLOW}ryoiki${NC}"
fi

echo -e "\n  ${YELLOW}Ultimate Version (Sophisticated UI):${NC}"
echo -e "    ./ryoiki-ui"
if [[ -L /usr/local/bin/ryoiki-ui ]]; then
    echo -e "    ${GREEN}or simply: ${YELLOW}ryoiki-ui${NC}"
fi

echo -e "\n  ${YELLOW}Alternative (Direct Python):${NC}"
echo -e "    source venv/bin/activate"
echo -e "    python ryoiki_tenkai_pro.py      # Professional"
echo -e "    python ryoiki_tenkai_ultimate.py # Ultimate UI"

echo -e "\n${CYAN}First Time Usage:${NC}"
echo -e "  1. Run in dry-run mode first (safe testing)"
echo -e "  2. Review available tools with tool reference"
echo -e "  3. Only test authorized targets"

echo -e "\n${CYAN}Documentation:${NC}"
echo -e "  cat README.md       # General guide"
echo -e "  cat UI_GUIDE.md     # UI documentation"
echo -e "  cat WHATS_NEW.md    # Feature comparison"

echo -e "\n${CYAN}Virtual Environment:${NC}"
echo -e "  Packages installed in: ${YELLOW}./venv${NC}"
echo -e "  Activate manually: ${YELLOW}source venv/bin/activate${NC}"
echo -e "  Deactivate: ${YELLOW}deactivate${NC}"

echo -e "\n${YELLOW}Remember: Always obtain proper authorization!${NC}\n"
