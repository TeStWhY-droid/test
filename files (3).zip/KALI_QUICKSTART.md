# Ryoiki Tenkai - Kali Linux Quick Start

## 🐉 Kali Linux Installation Guide

This guide is specifically for Kali Linux users dealing with Python's externally managed environment.

---

## ⚡ Quick Installation (Recommended)

```bash
# 1. Run the automated setup script
./setup.sh

# 2. Launch the tool
./ryoiki              # Professional version
./ryoiki-ui           # Ultimate UI version
```

The setup script automatically:
- ✅ Creates a Python virtual environment
- ✅ Installs dependencies (rich, requests)
- ✅ Downloads the Ollama model
- ✅ Creates convenient launcher scripts
- ✅ Verifies Kali tools

---

## 🔧 Manual Installation (If Automated Fails)

### Step 1: Create Virtual Environment

```bash
# Install venv if needed
sudo apt install python3-venv

# Create virtual environment
python3 -m venv venv

# Activate it
source venv/bin/activate
```

### Step 2: Install Dependencies

```bash
# Upgrade pip
pip install --upgrade pip

# Install required packages
pip install rich requests
```

### Step 3: Install Ollama & Model

```bash
# Install Ollama
curl -fsSL https://ollama.ai/install.sh | sh

# Start Ollama service
ollama serve &

# Download the model
ollama pull ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q5_K_M
```

### Step 4: Test Installation

```bash
# Test professional version
python ryoiki_tenkai_pro.py

# Test ultimate UI version
python ryoiki_tenkai_ultimate.py
```

---

## 🚀 Usage

### Method 1: Using Wrapper Scripts (Easiest)

```bash
# Professional version (standard UI)
./ryoiki

# Ultimate version (sophisticated UI)
./ryoiki-ui
```

### Method 2: Direct Python Execution

```bash
# Activate virtual environment first
source venv/bin/activate

# Run professional version
python ryoiki_tenkai_pro.py

# Run ultimate version
python ryoiki_tenkai_ultimate.py

# Deactivate when done
deactivate
```

### Method 3: System-Wide Command (If Installed)

```bash
# If you created symlinks during setup
ryoiki       # Professional version
ryoiki-ui    # Ultimate UI version
```

---

## 🐛 Troubleshooting

### Issue: "externally-managed-environment" Error

**Problem**: Kali Linux prevents system-wide pip installations

**Solution**: Always use the virtual environment
```bash
source venv/bin/activate
pip install <package>
```

### Issue: "ModuleNotFoundError: No module named 'rich'"

**Problem**: Running outside virtual environment

**Solution**: Use wrapper scripts or activate venv
```bash
# Option 1: Use wrapper
./ryoiki

# Option 2: Activate venv
source venv/bin/activate
python ryoiki_tenkai_pro.py
```

### Issue: "python3-venv not found"

**Problem**: venv module not installed

**Solution**: Install it
```bash
sudo apt update
sudo apt install python3-venv
```

### Issue: "Cannot connect to Ollama"

**Problem**: Ollama service not running

**Solution**: Start Ollama
```bash
# Start in background
ollama serve &

# Or in separate terminal
ollama serve

# Verify it's running
curl http://localhost:11434/api/tags
```

### Issue: "Model not found"

**Problem**: Qwen3 model not downloaded

**Solution**: Download the model
```bash
ollama pull ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q5_K_M

# Verify installation
ollama list
```

### Issue: Terminal UI looks broken

**Problem**: Terminal too small or wrong encoding

**Solution**: Resize terminal
```bash
# Check current size
tput cols  # Should be 120+
tput lines # Should be 30+

# For ultimate UI, recommended: 140x40
resize -s 40 140

# Ensure UTF-8 encoding
export LANG=en_US.UTF-8
export LC_ALL=en_US.UTF-8
```

---

## 📦 Understanding the Virtual Environment

### What is it?

A virtual environment is an isolated Python environment that:
- ✅ Doesn't interfere with system Python
- ✅ Allows package installation without sudo
- ✅ Keeps dependencies organized
- ✅ Is the modern Python best practice

### Directory Structure

```
ryoiki/
├── venv/                    # Virtual environment
│   ├── bin/
│   │   ├── python          # Isolated Python
│   │   ├── pip             # Isolated pip
│   │   └── activate        # Activation script
│   └── lib/
│       └── python3.X/
│           └── site-packages/  # Installed packages
├── ryoiki                   # Wrapper script (pro)
├── ryoiki-ui                # Wrapper script (ultimate)
├── ryoiki_tenkai_pro.py     # Main script (pro)
└── ryoiki_tenkai_ultimate.py # Main script (ultimate)
```

### Commands Cheat Sheet

```bash
# Activate venv
source venv/bin/activate

# Check which Python is active
which python   # Should show: /path/to/ryoiki/venv/bin/python

# Install packages
pip install <package>

# List installed packages
pip list

# Deactivate venv
deactivate

# Delete venv (if needed)
rm -rf venv
```

---

## 🎯 Kali-Specific Tips

### 1. Verify Kali Tools

```bash
# Check if essential tools are installed
which nmap gobuster nikto sqlmap hydra

# Install missing tools
sudo apt update
sudo apt install nmap gobuster nikto sqlmap hydra
```

### 2. Wordlists Location

```bash
# Kali wordlists are in:
ls /usr/share/wordlists/

# Common ones:
# - /usr/share/wordlists/dirb/common.txt
# - /usr/share/wordlists/rockyou.txt (needs gunzip)
# - /usr/share/wordlists/dirbuster/

# Unzip rockyou if needed
sudo gunzip /usr/share/wordlists/rockyou.txt.gz
```

### 3. Running as Root (Not Recommended)

```bash
# Some tools require root (tcpdump, etc.)
# Better: Use sudo for specific commands

# If you must run entire agent as root:
sudo su
source venv/bin/activate
python ryoiki_tenkai_pro.py
```

### 4. Integration with Kali Workflows

```bash
# Use with tmux for session management
tmux new -s pentest
./ryoiki-ui
# Detach: Ctrl+B, D
# Reattach: tmux attach -t pentest

# Logging all output
./ryoiki 2>&1 | tee engagement.log

# Running in background
nohup ./ryoiki &
```

---

## 🔐 Security Best Practices

### 1. Virtual Environment Isolation

✅ **DO**: Keep venv in project directory  
✅ **DO**: Use separate venvs for different projects  
❌ **DON'T**: Share venvs between unrelated projects  
❌ **DON'T**: Install packages globally with `--break-system-packages`  

### 2. Engagement Safety

```bash
# Always test in dry-run mode first
# Edit ryoiki_tenkai_pro.py or ryoiki_tenkai_ultimate.py:
Config.DRY_RUN = True   # Safe testing

# Then switch to live:
Config.DRY_RUN = False  # Real execution
```

### 3. Workspace Organization

```bash
# Each engagement gets its own directory
ryoiki/
└── engagements/
    ├── client1.com/
    ├── client2.net/
    └── ctf-box/
```

---

## 📊 System Requirements

### Minimum (Professional Version)

```
CPU:    2 cores, 2.0 GHz
RAM:    4 GB
Disk:   10 GB free
Python: 3.8+
Kali:   2020.1+
```

### Recommended (Ultimate UI Version)

```
CPU:    4 cores, 3.0 GHz
RAM:    8 GB
Disk:   20 GB free
Python: 3.10+
Kali:   2023.1+
Terminal: 140x40, true color
```

---

## 🎓 Learning Resources

### Kali Linux Python

- **Official Docs**: https://www.kali.org/docs/general-use/python3-external-packages/
- **Virtual Envs**: https://docs.python.org/3/tutorial/venv.html
- **PEP 668**: https://peps.python.org/pep-0668/ (externally managed environments)

### Penetration Testing

- **Kali Tools**: https://www.kali.org/tools/
- **PTES**: http://www.pentest-standard.org/
- **OWASP**: https://owasp.org/www-project-web-security-testing-guide/

### Ollama

- **Main Site**: https://ollama.ai/
- **Model Library**: https://ollama.ai/library
- **API Docs**: https://github.com/ollama/ollama/blob/main/docs/api.md

---

## 🎯 Quick Reference Commands

```bash
# Installation
./setup.sh

# Basic Usage
./ryoiki              # Professional UI
./ryoiki-ui           # Ultimate UI

# Manual venv
source venv/bin/activate
python ryoiki_tenkai_pro.py
deactivate

# Ollama Management
ollama serve          # Start service
ollama list           # List models
ollama ps             # Running models
ollama pull <model>   # Download model

# Troubleshooting
which python          # Check Python path
pip list              # List packages
tput cols && tput lines  # Check terminal size
```

---

## 💡 Pro Tips

### 1. Alias for Quick Access

Add to `~/.bashrc` or `~/.zshrc`:

```bash
alias ryoiki='cd ~/Downloads/ryoiki && ./ryoiki'
alias ryoiki-ui='cd ~/Downloads/ryoiki && ./ryoiki-ui'
```

### 2. Auto-activate venv

Create `~/.ryoikirc`:

```bash
# Auto-activate venv when entering directory
cd ~/Downloads/ryoiki
source venv/bin/activate
```

### 3. Custom Terminal Size

For ultimate UI, create terminal profile:

```
Name: Ryoiki UI
Columns: 140
Rows: 40
Font: Fira Code, 12pt
Theme: Dracula
```

---

## 🆘 Getting Help

### Command Help

```bash
# View available options
./ryoiki --help
python ryoiki_tenkai_pro.py --help

# Interactive tool selection
./ryoiki
> Select: View tool reference
```

### Documentation

```bash
cat README.md        # Main documentation
cat UI_GUIDE.md      # UI walkthrough
cat EXAMPLES.md      # Usage examples
cat WHATS_NEW.md     # Feature comparison
```

### Community

- **Report Issues**: GitHub Issues
- **Feature Requests**: Discussions
- **Security Issues**: Private disclosure

---

## ✅ Installation Checklist

- [ ] Python 3.8+ installed
- [ ] Virtual environment created
- [ ] Dependencies installed (rich, requests)
- [ ] Ollama installed and running
- [ ] Qwen3 model downloaded
- [ ] Kali tools verified
- [ ] Wrapper scripts created
- [ ] Test run successful
- [ ] Terminal properly sized (for UI version)
- [ ] Authorized targets only!

---

## 🎉 Ready to Go!

You're all set! Start your first engagement:

```bash
./ryoiki-ui
```

**Remember**: Always obtain proper authorization before testing!

---

*Happy Hacking! 🐉*
