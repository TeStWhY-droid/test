#!/usr/bin/env python3
"""
█▀█ █▄█ █▀█ █ █▄▀ █   ▀█▀ █▀▀ █▄ █ █▄▀ ▄▀█ █
█▀▄  █  █▄█ █ █ █ █    █  ██▄ █ ▀█ █ █ █▀█ █

Ryoiki Tenkai (領域展開) — Advanced Pentest Orchestration Agent
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Professional Penetration Testing Framework for Kali Linux
Modes: RECON | ENUM | VULN | EXPLOIT | REPORT | CTF | BUG_HUNT

FREE • OFFLINE • AUDITABLE • LAB-SAFE
"""

import os, sys, json, subprocess, re, requests, time
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
from urllib.parse import urlparse
from collections import defaultdict

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt, Confirm
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
from rich.table import Table
from rich.layout import Layout
from rich.live import Live
from rich.tree import Tree
from rich.syntax import Syntax
from rich.markdown import Markdown
from rich.align import Align
from rich import box

console = Console()

# ═══════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

class Config:
    """Global configuration for the agent"""
    MODEL = "ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q5_K_M"
    MAX_ITERATIONS = 50
    OLLAMA_URL = "http://localhost:11434/api/generate"
    
    DRY_RUN = True  # Set to False for real execution
    TERMINAL_TIMEOUT = 900
    
    BASE_WORKSPACE = Path.cwd().resolve()
    LOG_NAME = "agent.log"
    FINDINGS_DB = "findings.json"
    
    # UI Settings
    THEME_COLOR = "cyan"
    ERROR_COLOR = "red"
    SUCCESS_COLOR = "green"
    WARNING_COLOR = "yellow"

# ═══════════════════════════════════════════════════════════════════════════
# PENTEST LIFECYCLE & TOOL MAPPING
# ═══════════════════════════════════════════════════════════════════════════

class Phase(Enum):
    """Penetration testing lifecycle phases"""
    RECON = "reconnaissance"
    ENUM = "enumeration"
    VULN = "vulnerability_analysis"
    EXPLOIT = "exploitation"
    POST = "post_exploitation"
    REPORT = "reporting"
    CTF = "ctf_mode"
    BUG_HUNT = "bug_bounty"

@dataclass
class Tool:
    """Tool metadata and usage context"""
    name: str
    purpose: str
    phases: List[Phase]
    typical_usage: str
    output_format: str = "text"
    requires_target: bool = True

# ═══════════════════════════════════════════════════════════════════════════
# COMPREHENSIVE KALI TOOLKIT
# ═══════════════════════════════════════════════════════════════════════════

PENTEST_TOOLKIT = {
    # ────────────────────────────────────────────────────────────────────────
    # RECONNAISSANCE
    # ────────────────────────────────────────────────────────────────────────
    "nmap": Tool(
        "nmap", 
        "Network scanning and service detection",
        [Phase.RECON, Phase.ENUM],
        "nmap -sV -sC -oN recon/nmap_scan.txt {target}",
        "text"
    ),
    "masscan": Tool(
        "masscan",
        "Ultra-fast port scanner",
        [Phase.RECON],
        "masscan {target} -p1-65535 --rate=1000 -oL recon/masscan.txt"
    ),
    "amass": Tool(
        "amass",
        "Subdomain enumeration and OSINT",
        [Phase.RECON],
        "amass enum -passive -d {domain} -o recon/subdomains.txt"
    ),
    "subfinder": Tool(
        "subfinder",
        "Fast passive subdomain discovery",
        [Phase.RECON],
        "subfinder -d {domain} -o recon/subfinder.txt"
    ),
    "dnsenum": Tool(
        "dnsenum",
        "DNS enumeration",
        [Phase.RECON],
        "dnsenum {domain} --output recon/dns.txt"
    ),
    "whois": Tool(
        "whois",
        "Domain registration information",
        [Phase.RECON],
        "whois {domain} > recon/whois.txt"
    ),
    "theHarvester": Tool(
        "theHarvester",
        "Email and subdomain harvesting",
        [Phase.RECON],
        "theHarvester -d {domain} -b all -f recon/harvest"
    ),
    
    # ────────────────────────────────────────────────────────────────────────
    # WEB ENUMERATION
    # ────────────────────────────────────────────────────────────────────────
    "gobuster": Tool(
        "gobuster",
        "Directory and file brute-forcing",
        [Phase.ENUM],
        "gobuster dir -u {url} -w /usr/share/wordlists/dirb/common.txt -o enum/gobuster.txt"
    ),
    "ffuf": Tool(
        "ffuf",
        "Fast web fuzzer",
        [Phase.ENUM],
        "ffuf -u {url}/FUZZ -w /usr/share/wordlists/dirb/common.txt -o enum/ffuf.json"
    ),
    "dirsearch": Tool(
        "dirsearch",
        "Web path scanner",
        [Phase.ENUM],
        "dirsearch -u {url} -o enum/dirsearch.txt"
    ),
    "feroxbuster": Tool(
        "feroxbuster",
        "Recursive content discovery",
        [Phase.ENUM],
        "feroxbuster -u {url} -o enum/feroxbuster.txt"
    ),
    "nikto": Tool(
        "nikto",
        "Web server vulnerability scanner",
        [Phase.VULN],
        "nikto -h {url} -output enum/nikto.txt"
    ),
    "whatweb": Tool(
        "whatweb",
        "Web technology fingerprinting",
        [Phase.ENUM],
        "whatweb {url} -v > enum/whatweb.txt"
    ),
    "wpscan": Tool(
        "wpscan",
        "WordPress vulnerability scanner",
        [Phase.VULN],
        "wpscan --url {url} --enumerate ap,at,u -o enum/wpscan.txt"
    ),
    "httpx": Tool(
        "httpx",
        "HTTP toolkit for probing",
        [Phase.ENUM],
        "httpx -list recon/subdomains.txt -o enum/httpx.txt"
    ),
    
    # ────────────────────────────────────────────────────────────────────────
    # VULNERABILITY ANALYSIS
    # ────────────────────────────────────────────────────────────────────────
    "sqlmap": Tool(
        "sqlmap",
        "SQL injection detection and exploitation",
        [Phase.VULN, Phase.EXPLOIT],
        "sqlmap -u {url} --batch --output-dir=exploits/sqlmap"
    ),
    "nuclei": Tool(
        "nuclei",
        "Template-based vulnerability scanner",
        [Phase.VULN],
        "nuclei -u {url} -o enum/nuclei.txt"
    ),
    "wfuzz": Tool(
        "wfuzz",
        "Web application fuzzer",
        [Phase.VULN],
        "wfuzz -w /usr/share/wordlists/wfuzz/general/common.txt {url}/FUZZ"
    ),
    "commix": Tool(
        "commix",
        "Command injection exploiter",
        [Phase.VULN, Phase.EXPLOIT],
        "commix --url={url}"
    ),
    "xsser": Tool(
        "xsser",
        "XSS detection and exploitation",
        [Phase.VULN],
        "xsser -u {url} --auto"
    ),
    
    # ────────────────────────────────────────────────────────────────────────
    # EXPLOITATION
    # ────────────────────────────────────────────────────────────────────────
    "msfconsole": Tool(
        "msfconsole",
        "Metasploit Framework console",
        [Phase.EXPLOIT, Phase.POST],
        "msfconsole -q -x 'use {module}; set RHOSTS {target}; run'",
        requires_target=False
    ),
    "msfvenom": Tool(
        "msfvenom",
        "Payload generator",
        [Phase.EXPLOIT],
        "msfvenom -p {payload} LHOST={lhost} LPORT={lport} -f {format} -o exploits/payload.{ext}"
    ),
    "hydra": Tool(
        "hydra",
        "Network login cracker",
        [Phase.EXPLOIT],
        "hydra -L users.txt -P passwords.txt {protocol}://{target} -o exploits/hydra.txt"
    ),
    "medusa": Tool(
        "medusa",
        "Parallel password cracker",
        [Phase.EXPLOIT],
        "medusa -h {target} -U users.txt -P passwords.txt -M {service}"
    ),
    
    # ────────────────────────────────────────────────────────────────────────
    # PASSWORD CRACKING
    # ────────────────────────────────────────────────────────────────────────
    "john": Tool(
        "john",
        "Password hash cracker",
        [Phase.EXPLOIT, Phase.POST],
        "john --wordlist=/usr/share/wordlists/rockyou.txt {hashfile}",
        requires_target=False
    ),
    "hashcat": Tool(
        "hashcat",
        "Advanced password recovery",
        [Phase.EXPLOIT, Phase.POST],
        "hashcat -m {mode} {hashfile} /usr/share/wordlists/rockyou.txt",
        requires_target=False
    ),
    
    # ────────────────────────────────────────────────────────────────────────
    # NETWORK ANALYSIS
    # ────────────────────────────────────────────────────────────────────────
    "wireshark": Tool(
        "wireshark",
        "Network protocol analyzer",
        [Phase.ENUM, Phase.POST],
        "wireshark -i {interface} -k",
        requires_target=False
    ),
    "tcpdump": Tool(
        "tcpdump",
        "Packet analyzer",
        [Phase.ENUM],
        "tcpdump -i {interface} -w enum/capture.pcap",
        requires_target=False
    ),
    "netdiscover": Tool(
        "netdiscover",
        "Network address discovery",
        [Phase.RECON],
        "netdiscover -r {network}"
    ),
    
    # ────────────────────────────────────────────────────────────────────────
    # UTILITIES
    # ────────────────────────────────────────────────────────────────────────
    "curl": Tool("curl", "HTTP client", [Phase.ENUM, Phase.VULN], "curl -v {url}", requires_target=False),
    "wget": Tool("wget", "File downloader", [Phase.RECON], "wget {url}", requires_target=False),
    "nc": Tool("nc", "Network swiss army knife", [Phase.EXPLOIT], "nc -lvnp {port}", requires_target=False),
    "netcat": Tool("netcat", "Network utility", [Phase.EXPLOIT], "netcat -lvnp {port}", requires_target=False),
    "python3": Tool("python3", "Python interpreter", [Phase.EXPLOIT], "python3 {script}", requires_target=False),
    "bash": Tool("bash", "Shell", [Phase.EXPLOIT], "bash {script}", requires_target=False),
    
    # System commands
    "ls": Tool("ls", "List files", [], "ls -la", requires_target=False),
    "cat": Tool("cat", "Read files", [], "cat {file}", requires_target=False),
    "grep": Tool("grep", "Search text", [], "grep {pattern} {file}", requires_target=False),
    "find": Tool("find", "Find files", [], "find {path} -name {pattern}", requires_target=False),
    "chmod": Tool("chmod", "Change permissions", [], "chmod +x {file}", requires_target=False),
    "whoami": Tool("whoami", "Current user", [], "whoami", requires_target=False),
    "id": Tool("id", "User identity", [], "id", requires_target=False),
    "pwd": Tool("pwd", "Current directory", [], "pwd", requires_target=False),
}

# Allowed tool names
ALLOWED_TOOLS = set(PENTEST_TOOLKIT.keys())

# ═══════════════════════════════════════════════════════════════════════════
# DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════

class ActionType(Enum):
    """Available actions for the agent"""
    READ_FILE = "read_file"
    WRITE_FILE = "write_file"
    EXECUTE = "execute_command"
    LIST = "list_files"
    CODE_GEN = "generate_code"
    ANALYZE = "analyze_output"
    DONE = "done"

@dataclass
class Action:
    """Structured action from LLM"""
    type: ActionType
    reasoning: str
    params: Dict
    metadata: Dict = field(default_factory=dict)

@dataclass
class Observation:
    """Result of executing an action"""
    success: bool
    output: str
    error: Optional[str] = None
    metadata: Dict = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)

@dataclass
class Finding:
    """Security finding or vulnerability"""
    severity: str  # critical, high, medium, low, info
    title: str
    description: str
    evidence: str
    remediation: str
    cvss: Optional[float] = None
    cve: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.now)

# ═══════════════════════════════════════════════════════════════════════════
# SECURITY & UTILITIES
# ═══════════════════════════════════════════════════════════════════════════

def sanitize_target(url: str) -> str:
    """Sanitize target URL for directory naming"""
    parsed = urlparse(url)
    netloc = parsed.netloc or parsed.path
    return re.sub(r'[^\w\-.]', '_', netloc)

def safe_path(base: Path, p: Path) -> Path:
    """Ensure path is within workspace (prevent directory traversal)"""
    resolved = p.resolve() if p.is_absolute() else (base / p).resolve()
    if not str(resolved).startswith(str(base)):
        raise PermissionError(f"Path escape attempt blocked: {p}")
    return resolved

def format_severity(severity: str) -> str:
    """Color-code severity levels"""
    colors = {
        "critical": "bold red",
        "high": "red",
        "medium": "yellow",
        "low": "blue",
        "info": "cyan"
    }
    return f"[{colors.get(severity.lower(), 'white')}]{severity.upper()}[/]"

# ═══════════════════════════════════════════════════════════════════════════
# ENHANCED TOOLKIT
# ═══════════════════════════════════════════════════════════════════════════

class EnhancedToolKit:
    """Advanced toolkit with intelligent tool selection and output parsing"""
    
    def __init__(self, workspace: Path):
        self.ws = workspace
        self.execution_log = []
        self.findings: List[Finding] = []
        
    def get_recommended_tools(self, phase: Phase) -> List[Tool]:
        """Get tools recommended for a specific phase"""
        return [tool for tool in PENTEST_TOOLKIT.values() if phase in tool.phases]
    
    def execute_command(self, cmd: str, phase: Optional[Phase] = None) -> Observation:
        """Execute a command with validation and logging"""
        # Extract command binary
        binary = cmd.strip().split()[0]
        
        # Validate against allowlist
        if binary not in ALLOWED_TOOLS:
            return Observation(
                success=False,
                output="",
                error=f"⛔ Command not allowed: {binary}\nUse 'list_tools' to see available tools."
            )
        
        # Log execution
        self.execution_log.append({
            "timestamp": datetime.now().isoformat(),
            "command": cmd,
            "phase": phase.value if phase else "unknown"
        })
        
        # Dry run mode
        if Config.DRY_RUN:
            tool_info = PENTEST_TOOLKIT.get(binary)
            return Observation(
                success=True,
                output=f"""🔍 DRY RUN MODE - Command would execute:
                
Command: {cmd}
Tool: {tool_info.name if tool_info else binary}
Purpose: {tool_info.purpose if tool_info else 'N/A'}

Set Config.DRY_RUN = False for real execution.""",
                metadata={"dry_run": True, "tool": binary}
            )
        
        # Real execution
        try:
            result = subprocess.run(
                cmd,
                shell=True,
                cwd=self.ws,
                capture_output=True,
                text=True,
                timeout=Config.TERMINAL_TIMEOUT
            )
            
            output = result.stdout + result.stderr
            success = result.returncode == 0
            
            # Parse output for findings
            if success:
                self._parse_for_findings(binary, output)
            
            return Observation(
                success=success,
                output=output,
                metadata={"returncode": result.returncode, "tool": binary}
            )
            
        except subprocess.TimeoutExpired:
            return Observation(
                success=False,
                output="",
                error=f"⏱️ Command timed out after {Config.TERMINAL_TIMEOUT}s"
            )
        except Exception as e:
            return Observation(
                success=False,
                output="",
                error=f"❌ Execution error: {str(e)}"
            )
    
    def _parse_for_findings(self, tool: str, output: str):
        """Parse tool output for security findings"""
        # Simple pattern matching - extend as needed
        patterns = {
            "sql injection": ("high", "Potential SQL Injection"),
            "xss": ("medium", "Possible XSS Vulnerability"),
            "open port": ("info", "Open Port Detected"),
            "vulnerable": ("medium", "Vulnerability Found"),
            "exploit": ("high", "Exploitable Issue"),
        }
        
        for pattern, (severity, title) in patterns.items():
            if pattern.lower() in output.lower():
                finding = Finding(
                    severity=severity,
                    title=f"{title} ({tool})",
                    description=f"Detected by {tool}",
                    evidence=output[:500],  # First 500 chars
                    remediation="Review and validate finding manually"
                )
                self.findings.append(finding)
    
    def write_file(self, path: str, content: str) -> Observation:
        """Write content to a file"""
        try:
            file_path = safe_path(self.ws, self.ws / path)
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(content, encoding="utf-8")
            
            return Observation(
                success=True,
                output=f"✅ Written to: {path} ({len(content)} bytes)",
                metadata={"path": str(file_path), "size": len(content)}
            )
        except Exception as e:
            return Observation(
                success=False,
                output="",
                error=f"❌ Write error: {str(e)}"
            )
    
    def read_file(self, path: str) -> Observation:
        """Read file contents"""
        try:
            file_path = safe_path(self.ws, self.ws / path)
            content = file_path.read_text(encoding="utf-8", errors="ignore")
            
            return Observation(
                success=True,
                output=content,
                metadata={"path": str(file_path), "size": len(content)}
            )
        except Exception as e:
            return Observation(
                success=False,
                output="",
                error=f"❌ Read error: {str(e)}"
            )
    
    def list_files(self, path: str = ".") -> Observation:
        """List directory contents"""
        try:
            dir_path = safe_path(self.ws, self.ws / path)
            
            if not dir_path.exists():
                return Observation(False, "", f"Directory not found: {path}")
            
            tree = Tree(f"📁 {path}")
            
            for item in sorted(dir_path.iterdir()):
                icon = "📁" if item.is_dir() else "📄"
                tree.add(f"{icon} {item.name}")
            
            # Convert tree to string for LLM
            items = [f"{'📁' if i.is_dir() else '📄'} {i.name}" for i in sorted(dir_path.iterdir())]
            
            return Observation(
                success=True,
                output="\n".join(items),
                metadata={"path": str(dir_path)}
            )
        except Exception as e:
            return Observation(False, "", f"❌ List error: {str(e)}")
    
    def generate_code(self, language: str, purpose: str, code: str) -> Observation:
        """Generate and save code files"""
        extensions = {
            "python": "py",
            "bash": "sh",
            "ruby": "rb",
            "perl": "pl",
            "javascript": "js"
        }
        
        ext = extensions.get(language.lower(), "txt")
        filename = f"generated_{datetime.now().strftime('%Y%m%d_%H%M%S')}.{ext}"
        filepath = self.ws / "exploits" / filename
        
        try:
            filepath.parent.mkdir(exist_ok=True)
            filepath.write_text(code, encoding="utf-8")
            
            # Make executable if script
            if ext in ["sh", "py", "rb", "pl"]:
                filepath.chmod(0o755)
            
            return Observation(
                success=True,
                output=f"""✅ Code generated: {filename}
Language: {language}
Purpose: {purpose}
Path: exploits/{filename}
Permissions: {'Executable' if ext in ['sh', 'py'] else 'Regular'}""",
                metadata={"path": str(filepath), "language": language}
            )
        except Exception as e:
            return Observation(False, "", f"❌ Code generation error: {str(e)}")

# ═══════════════════════════════════════════════════════════════════════════
# SOPHISTICATED PENTEST AGENT
# ═══════════════════════════════════════════════════════════════════════════

class ProfessionalPentestAgent:
    """Advanced penetration testing agent with intelligent automation"""
    
    def __init__(self, phase: Phase, target: Optional[str] = None):
        self.phase = phase
        self.target = target
        self.workspace = self._prepare_workspace()
        self.toolkit = EnhancedToolKit(self.workspace)
        self.history = []
        self.iteration = 0
        self.start_time = datetime.now()
        
    def _prepare_workspace(self) -> Path:
        """Create organized workspace structure"""
        if self.target:
            name = sanitize_target(self.target)
            ws = Config.BASE_WORKSPACE / "engagements" / name
        else:
            ws = Config.BASE_WORKSPACE / "workspace"
        
        # Create directory structure
        directories = ["recon", "enum", "exploits", "reports", "loot", "screenshots"]
        for d in directories:
            (ws / d).mkdir(parents=True, exist_ok=True)
        
        # Create metadata file
        metadata = {
            "target": self.target,
            "phase": self.phase.value,
            "created": datetime.now().isoformat(),
            "agent_version": "2.0"
        }
        
        (ws / "metadata.json").write_text(json.dumps(metadata, indent=2))
        
        return ws
    
    def _build_system_prompt(self) -> str:
        """Construct comprehensive system prompt"""
        
        # Get recommended tools for current phase
        recommended_tools = self.toolkit.get_recommended_tools(self.phase)
        tool_list = "\n".join([
            f"  • {t.name}: {t.purpose}\n    Usage: {t.typical_usage}"
            for t in recommended_tools[:10]  # Top 10
        ])
        
        return f"""╔═══════════════════════════════════════════════════════════════╗
║  PROFESSIONAL PENETRATION TESTING AGENT                       ║
║  Kali Linux Automated Security Assessment Framework          ║
╚═══════════════════════════════════════════════════════════════╝

┌─────────────────────────────────────────────────────────────┐
│ ENGAGEMENT PARAMETERS                                        │
├─────────────────────────────────────────────────────────────┤
│ Phase:      {self.phase.value.upper()}
│ Target:     {self.target or 'N/A'}
│ Workspace:  {self.workspace}
│ Mode:       {'DRY RUN' if Config.DRY_RUN else 'LIVE EXECUTION'}
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ CORE COMPETENCIES                                           │
├─────────────────────────────────────────────────────────────┤
│ 1. INTELLIGENT TOOL SELECTION                               │
│    - Auto-select optimal tools for each phase              │
│    - Chain tools for comprehensive coverage                │
│    - Parse and correlate outputs                           │
│                                                             │
│ 2. CODE GENERATION                                          │
│    - Generate exploits (Python, Bash, Ruby)                │
│    - Create custom enumeration scripts                     │
│    - Build proof-of-concept payloads                       │
│                                                             │
│ 3. PROFESSIONAL REPORTING                                   │
│    - Track all findings with severity ratings             │
│    - Generate executive summaries                          │
│    - Provide actionable remediation                        │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ RECOMMENDED TOOLS FOR {self.phase.value.upper()}
├─────────────────────────────────────────────────────────────┤
{tool_list}
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ OPERATIONAL GUIDELINES                                      │
├─────────────────────────────────────────────────────────────┤
│ ✓ Always operate within authorized scope                   │
│ ✓ Follow penetration testing methodology                   │
│ ✓ Save ALL outputs to appropriate directories             │
│ ✓ Document every finding with evidence                    │
│ ✓ Generate code when manual work is repetitive            │
│ ✓ Chain tools intelligently for better coverage           │
│ ✓ Prioritize findings by severity                         │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ RESPONSE FORMAT                                             │
├─────────────────────────────────────────────────────────────┤
│ You MUST respond in valid JSON format:                     │
│                                                             │
│ {{                                                           │
│   "thinking": "Your analytical reasoning here",            │
│   "action": "execute_command|write_file|generate_code|done",│
│   "params": {{                                               │
│     // Action-specific parameters                          │
│   }},                                                       │
│   "next_steps": ["Step 1", "Step 2"],                      │
│   "done": false                                            │
│ }}                                                           │
│                                                             │
│ AVAILABLE ACTIONS:                                          │
│ • execute_command: Run Kali tools                          │
│ • write_file: Save reports/data                            │
│ • read_file: Read previous outputs                         │
│ • generate_code: Create scripts/exploits                   │
│ • list_files: View directory contents                      │
│ • done: Complete engagement                                │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ CODE GENERATION CAPABILITIES                                │
├─────────────────────────────────────────────────────────────┤
│ When you need to generate code, use:                       │
│ {{                                                           │
│   "action": "generate_code",                               │
│   "params": {{                                               │
│     "language": "python|bash|ruby",                        │
│     "purpose": "Brief description",                        │
│     "code": "Full code here..."                            │
│   }}                                                        │
│ }}                                                           │
│                                                             │
│ Examples:                                                   │
│ • Custom port scanner in Python                            │
│ • Bash script to parse nmap output                         │
│ • Ruby exploit for specific CVE                            │
│ • Python script for data extraction                        │
└─────────────────────────────────────────────────────────────┘

BEGIN ENGAGEMENT. Think step-by-step, choose appropriate tools,
and execute systematically. Document everything.
"""
    
    def _call_llm(self, prompt: str) -> str:
        """Call Ollama LLM with proper error handling"""
        try:
            with Progress(
                SpinnerColumn(),
                TextColumn("[cyan]Thinking..."),
                console=console
            ) as progress:
                progress.add_task("llm", total=None)
                
                response = requests.post(
                    Config.OLLAMA_URL,
                    json={
                        "model": Config.MODEL,
                        "prompt": prompt,
                        "stream": False,
                        "options": {
                            "temperature": 0.7,
                            "top_p": 0.9,
                        }
                    },
                    timeout=600
                )
                
                response.raise_for_status()
                return response.json()["response"]
                
        except requests.exceptions.ConnectionError:
            console.print("[red]❌ Cannot connect to Ollama. Is it running?[/red]")
            console.print("[yellow]Start with: ollama serve[/yellow]")
            sys.exit(1)
        except Exception as e:
            console.print(f"[red]❌ LLM Error: {str(e)}[/red]")
            return ""
    
    def _parse_action(self, text: str) -> Optional[Action]:
        """Parse LLM response into structured action"""
        try:
            # Extract JSON from response
            json_match = re.search(r'\{.*\}', text, re.DOTALL)
            if not json_match:
                return None
            
            data = json.loads(json_match.group())
            
            # Check if done
            if data.get("done", False):
                return Action(
                    type=ActionType.DONE,
                    reasoning=data.get("thinking", "Task completed"),
                    params={},
                    metadata={"next_steps": data.get("next_steps", [])}
                )
            
            # Parse action
            action_str = data.get("action", "")
            action_type = ActionType(action_str)
            
            return Action(
                type=action_type,
                reasoning=data.get("thinking", ""),
                params=data.get("params", {}),
                metadata={"next_steps": data.get("next_steps", [])}
            )
            
        except (json.JSONDecodeError, ValueError, KeyError) as e:
            console.print(f"[yellow]⚠️  Parse error: {str(e)}[/yellow]")
            return None
    
    def _display_banner(self):
        """Display professional startup banner"""
        banner = """
[bold cyan]╔═══════════════════════════════════════════════════════════════════════════╗
║                                                                           ║
║     █▀█ █▄█ █▀█ █ █▄▀ █   ▀█▀ █▀▀ █▄ █ █▄▀ ▄▀█ █                        ║
║     █▀▄  █  █▄█ █ █ █ █    █  ██▄ █ ▀█ █ █ █▀█ █                        ║
║                                                                           ║
║              Professional Penetration Testing Framework                  ║
║                   Kali Linux Security Assessment                         ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝[/bold cyan]
"""
        console.print(banner)
        
        # Engagement info table
        table = Table(show_header=False, box=box.ROUNDED, border_style="cyan")
        table.add_column("Key", style="bold cyan")
        table.add_column("Value", style="white")
        
        table.add_row("Phase", self.phase.value.upper())
        table.add_row("Target", self.target or "N/A")
        table.add_row("Workspace", str(self.workspace))
        table.add_row("Mode", "🔍 DRY RUN" if Config.DRY_RUN else "⚡ LIVE")
        table.add_row("Model", Config.MODEL)
        table.add_row("Max Iterations", str(Config.MAX_ITERATIONS))
        
        console.print(Panel(table, title="[bold]Engagement Configuration[/bold]", border_style="cyan"))
        console.print()
    
    def _display_action(self, action: Action, iteration: int):
        """Display action in professional format"""
        # Action header
        action_icons = {
            ActionType.EXECUTE: "⚡",
            ActionType.WRITE_FILE: "💾",
            ActionType.READ_FILE: "📖",
            ActionType.CODE_GEN: "🔧",
            ActionType.LIST: "📂",
            ActionType.DONE: "✅"
        }
        
        icon = action_icons.get(action.type, "▶️")
        title = f"{icon} Iteration {iteration} - {action.type.value.replace('_', ' ').title()}"
        
        # Reasoning panel
        console.print(Panel(
            Markdown(action.reasoning),
            title=f"[bold cyan]🧠 Analysis[/bold cyan]",
            border_style="cyan",
            padding=(1, 2)
        ))
        
        # Parameters
        if action.params:
            param_text = json.dumps(action.params, indent=2)
            console.print(Panel(
                Syntax(param_text, "json", theme="monokai", line_numbers=False),
                title=f"[bold yellow]📋 Parameters[/bold yellow]",
                border_style="yellow",
                padding=(1, 2)
            ))
    
    def _display_observation(self, obs: Observation):
        """Display observation results"""
        if obs.success:
            # Truncate long output
            output = obs.output
            if len(output) > 2000:
                output = output[:1000] + "\n\n... [truncated] ...\n\n" + output[-1000:]
            
            console.print(Panel(
                output,
                title="[bold green]✓ Output[/bold green]",
                border_style="green",
                padding=(1, 2)
            ))
        else:
            console.print(Panel(
                obs.error or "Unknown error",
                title="[bold red]✗ Error[/bold red]",
                border_style="red",
                padding=(1, 2)
            ))
    
    def _generate_final_report(self):
        """Generate comprehensive engagement report"""
        duration = (datetime.now() - self.start_time).total_seconds()
        
        report = f"""
# PENETRATION TESTING REPORT
## Ryoiki Tenkai Framework

---

### ENGAGEMENT SUMMARY

**Target:** {self.target or 'N/A'}
**Phase:** {self.phase.value.upper()}
**Start Time:** {self.start_time.strftime('%Y-%m-%d %H:%M:%S')}
**Duration:** {duration:.2f} seconds
**Iterations:** {self.iteration}

---

### FINDINGS ({len(self.toolkit.findings)})

"""
        
        # Group findings by severity
        by_severity = defaultdict(list)
        for finding in self.toolkit.findings:
            by_severity[finding.severity].append(finding)
        
        for severity in ["critical", "high", "medium", "low", "info"]:
            findings = by_severity.get(severity, [])
            if findings:
                report += f"\n#### {severity.upper()} ({len(findings)})\n\n"
                for i, f in enumerate(findings, 1):
                    report += f"""
**{i}. {f.title}**

- **Description:** {f.description}
- **Evidence:**
  ```
  {f.evidence[:200]}...
  ```
- **Remediation:** {f.remediation}

"""
        
        report += f"""
---

### EXECUTION LOG

Total commands executed: {len(self.toolkit.execution_log)}

"""
        
        for entry in self.toolkit.execution_log[-10:]:  # Last 10
            report += f"- [{entry['timestamp']}] {entry['command']}\n"
        
        report += "\n---\n\n*Report generated by Ryoiki Tenkai v2.0*\n"
        
        # Save report
        report_path = self.workspace / "reports" / f"engagement_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
        report_path.write_text(report, encoding="utf-8")
        
        console.print(Panel(
            f"[green]✓[/green] Report saved to: {report_path}",
            title="📊 Final Report",
            border_style="green"
        ))
        
        # Display findings summary
        if self.toolkit.findings:
            findings_table = Table(title="🎯 Findings Summary", box=box.ROUNDED)
            findings_table.add_column("Severity", style="bold")
            findings_table.add_column("Count", justify="right")
            
            for severity in ["critical", "high", "medium", "low", "info"]:
                count = len(by_severity.get(severity, []))
                if count > 0:
                    findings_table.add_row(format_severity(severity), str(count))
            
            console.print(findings_table)
    
    def run(self):
        """Main agent execution loop"""
        self._display_banner()
        
        # Initialize conversation
        self.history.append({
            "role": "system",
            "content": self._build_system_prompt()
        })
        
        try:
            for iteration in range(1, Config.MAX_ITERATIONS + 1):
                self.iteration = iteration
                
                # Build prompt from history
                prompt = "\n\n".join([
                    f"{'SYSTEM' if m['role'] == 'system' else m['role'].upper()}: {m['content']}"
                    for m in self.history
                ])
                
                # Get LLM response
                response = self._call_llm(prompt)
                
                if not response:
                    console.print("[red]Empty response from LLM[/red]")
                    break
                
                # Parse action
                action = self._parse_action(response)
                
                if not action:
                    console.print("[yellow]⚠️  Failed to parse action. Requesting fix...[/yellow]")
                    self.history.append({"role": "assistant", "content": response})
                    self.history.append({
                        "role": "user",
                        "content": "ERROR: Invalid JSON format. Please respond with valid JSON only."
                    })
                    continue
                
                # Display action
                self._display_action(action, iteration)
                
                # Check if done
                if action.type == ActionType.DONE:
                    console.print("\n[bold green]✓ ENGAGEMENT COMPLETE[/bold green]\n")
                    self._generate_final_report()
                    return
                
                # Execute action
                observation = self._execute_action(action)
                
                # Display observation
                self._display_observation(observation)
                
                # Update history
                self.history.append({"role": "assistant", "content": response})
                self.history.append({
                    "role": "user",
                    "content": f"OBSERVATION: {observation.output or observation.error}"
                })
                
                console.print()  # Spacing
            
            console.print("[yellow]⚠️  Maximum iterations reached[/yellow]")
            self._generate_final_report()
            
        except KeyboardInterrupt:
            console.print("\n[yellow]⚠️  Interrupted by user[/yellow]")
            self._generate_final_report()
        except Exception as e:
            console.print(f"\n[red]❌ Fatal error: {str(e)}[/red]")
            import traceback
            traceback.print_exc()
    
    def _execute_action(self, action: Action) -> Observation:
        """Execute an action and return observation"""
        try:
            if action.type == ActionType.EXECUTE:
                return self.toolkit.execute_command(
                    action.params.get("command", ""),
                    self.phase
                )
            
            elif action.type == ActionType.WRITE_FILE:
                return self.toolkit.write_file(
                    action.params.get("path", ""),
                    action.params.get("content", "")
                )
            
            elif action.type == ActionType.READ_FILE:
                return self.toolkit.read_file(action.params.get("path", ""))
            
            elif action.type == ActionType.LIST:
                return self.toolkit.list_files(action.params.get("path", "."))
            
            elif action.type == ActionType.CODE_GEN:
                return self.toolkit.generate_code(
                    action.params.get("language", "python"),
                    action.params.get("purpose", ""),
                    action.params.get("code", "")
                )
            
            else:
                return Observation(False, "", f"Unknown action type: {action.type}")
                
        except Exception as e:
            return Observation(False, "", f"Execution error: {str(e)}")

# ═══════════════════════════════════════════════════════════════════════════
# CLI INTERFACE
# ═══════════════════════════════════════════════════════════════════════════

def display_tool_reference():
    """Display available tools and their usage"""
    table = Table(title="🔧 Available Kali Tools", box=box.DOUBLE_EDGE)
    table.add_column("Tool", style="cyan", no_wrap=True)
    table.add_column("Purpose", style="white")
    table.add_column("Phases", style="yellow")
    
    for name, tool in sorted(PENTEST_TOOLKIT.items())[:20]:  # Show first 20
        phases = ", ".join([p.value[:4].upper() for p in tool.phases[:3]])
        table.add_row(name, tool.purpose[:50], phases)
    
    console.print(table)
    console.print(f"\n[cyan]Total tools available: {len(PENTEST_TOOLKIT)}[/cyan]\n")

def main():
    """Main CLI entry point"""
    
    # ASCII Art Header
    console.print("""
[bold magenta]
    ██████╗ ██╗   ██╗ ██████╗ ██╗██╗  ██╗██╗
    ██╔══██╗╚██╗ ██╔╝██╔═══██╗██║██║ ██╔╝██║
    ██████╔╝ ╚████╔╝ ██║   ██║██║█████╔╝ ██║
    ██╔══██╗  ╚██╔╝  ██║   ██║██║██╔═██╗ ██║
    ██║  ██║   ██║   ╚██████╔╝██║██║  ██╗██║
    ╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚═╝╚═╝  ╚═╝╚═╝
    
    ▀█▀ █▀▀ █▄ █ █▄▀ ▄▀█ █   — Professional Edition
     █  ██▄ █ ▀█ █ █ █▀█ █   — Kali Linux v2.0
[/bold magenta]
""")
    
    console.print("[dim]Advanced Penetration Testing Orchestration Agent[/dim]\n")
    
    # Check if user wants tool reference
    if Confirm.ask("📚 View available tools reference?", default=False):
        display_tool_reference()
    
    # Phase selection
    console.print("\n[bold cyan]Select Engagement Phase:[/bold cyan]")
    phase_choice = Prompt.ask(
        "Phase",
        choices=["recon", "enum", "vuln", "exploit", "post", "report", "ctf", "bug_hunt"],
        default="recon"
    )
    
    phase_map = {
        "recon": Phase.RECON,
        "enum": Phase.ENUM,
        "vuln": Phase.VULN,
        "exploit": Phase.EXPLOIT,
        "post": Phase.POST,
        "report": Phase.REPORT,
        "ctf": Phase.CTF,
        "bug_hunt": Phase.BUG_HUNT
    }
    
    phase = phase_map[phase_choice]
    
    # Target input
    target = None
    if phase in [Phase.RECON, Phase.ENUM, Phase.VULN, Phase.EXPLOIT, Phase.CTF, Phase.BUG_HUNT]:
        target = Prompt.ask("\n[bold yellow]🎯 Target[/bold yellow] (URL/IP) - Authorized only")
        
        if not Confirm.ask(f"\n⚠️  Confirm authorization to test: [bold]{target}[/bold]", default=False):
            console.print("[red]Engagement cancelled - no authorization confirmed[/red]")
            return
    
    # Configuration review
    console.print("\n[bold]Configuration Review:[/bold]")
    config_table = Table(show_header=False, box=box.SIMPLE)
    config_table.add_column("Setting", style="cyan")
    config_table.add_column("Value", style="white")
    
    config_table.add_row("Dry Run", "✓ Enabled" if Config.DRY_RUN else "✗ Disabled (LIVE)")
    config_table.add_row("Max Iterations", str(Config.MAX_ITERATIONS))
    config_table.add_row("Model", Config.MODEL)
    
    console.print(config_table)
    
    if not Confirm.ask("\n▶️  Start engagement?", default=True):
        console.print("[yellow]Engagement cancelled[/yellow]")
        return
    
    console.print("\n" + "═" * 80 + "\n")
    
    # Initialize and run agent
    try:
        agent = ProfessionalPentestAgent(phase, target)
        agent.run()
    except Exception as e:
        console.print(f"\n[bold red]❌ Fatal Error:[/bold red] {str(e)}")
        import traceback
        console.print("\n[dim]" + traceback.format_exc() + "[/dim]")

if __name__ == "__main__":
    main()
