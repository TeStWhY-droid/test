# Model Configuration - Quick Reference

## Current Model

**Model**: `ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q5_K_M`

### Model Details

- **Family**: Qwen3 (Latest generation)
- **Size**: 4 billion parameters
- **Quantization**: Q5_K_M (5-bit quantization, medium accuracy)
- **Specialization**: tcomanr-merge (optimized for technical/command tasks)
- **Version**: 2.5 (latest stable)

### Why This Model?

✅ **Optimized for Penetration Testing**
- Fine-tuned for technical command generation
- Better understanding of security tools and concepts
- Efficient code generation capabilities

✅ **Resource Efficient**
- 4B parameters with Q5_K_M quantization
- Requires ~3-4GB RAM
- Fast inference speed
- Suitable for laptops and modest hardware

✅ **Balanced Performance**
- High accuracy with 5-bit quantization
- Good balance between speed and quality
- Excellent for command-line tools

### System Requirements

**Minimum**:
- RAM: 4GB
- Disk: 3GB for model
- CPU: Any modern CPU (2015+)

**Recommended**:
- RAM: 8GB
- Disk: 10GB (including workspace)
- CPU: 4+ cores

### Installation

```bash
# Pull the model
ollama pull ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q5_K_M

# Verify installation
ollama list | grep Qwen3

# Test the model
ollama run ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q5_K_M "Hello"
```

## Alternative Models

If you need different performance characteristics:

### Faster (Lower RAM)
```bash
# Smaller quantization (faster, less accurate)
ollama pull ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q4_K_M
# Update in Config: MODEL = "ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q4_K_M"
```

### Higher Quality (More RAM)
```bash
# Larger quantization (slower, more accurate)
ollama pull ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q6_K
# Update in Config: MODEL = "ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q6_K"
```

### Standard Qwen Models (Fallback)
```bash
# If the specialized model is unavailable
ollama pull qwen2.5-coder:7b
# Update in Config: MODEL = "qwen2.5-coder:7b"
```

## Performance Comparison

| Model | Size | RAM | Speed | Quality | Use Case |
|-------|------|-----|-------|---------|----------|
| Qwen3-4b:Q4_K_M | 2.5GB | 3GB | ⚡⚡⚡ | ⭐⭐⭐ | Low-end systems |
| **Qwen3-4b:Q5_K_M** | **3GB** | **4GB** | **⚡⚡** | **⭐⭐⭐⭐** | **Recommended** |
| Qwen3-4b:Q6_K | 3.5GB | 5GB | ⚡ | ⭐⭐⭐⭐⭐ | High-end systems |
| qwen2.5-coder:7b | 4.7GB | 8GB | ⚡ | ⭐⭐⭐⭐ | General coding |
| qwen2.5-coder:14b | 9GB | 16GB | ⚡ | ⭐⭐⭐⭐⭐ | Best quality |

## Troubleshooting

### Model Not Found
```bash
# Check available models
ollama list

# Pull the model again
ollama pull ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q5_K_M
```

### Out of Memory
```bash
# Use smaller quantization
ollama pull ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q4_K_M

# Update config
sed -i 's/Q5_K_M/Q4_K_M/' ryoiki_tenkai_pro.py
```

### Slow Performance
```bash
# Check Ollama is using GPU (if available)
ollama ps

# Monitor resource usage
htop
```

## Customization

To change the model in Ryoiki Tenkai:

1. **Edit Config Class** (ryoiki_tenkai_pro.py, line ~72):
```python
class Config:
    MODEL = "your-model-name-here"
    # ... rest of config
```

2. **Pull New Model**:
```bash
ollama pull your-model-name-here
```

3. **Test**:
```bash
./ryoiki_tenkai_pro.py
```

## Model Behavior

### Qwen3-tcomanr-merge Advantages

✅ **Command Generation**: Excellent at generating shell commands
✅ **Tool Selection**: Understands Kali tools and their usage
✅ **Code Quality**: Produces functional scripts with minimal errors
✅ **Context Understanding**: Good at following pentest methodology
✅ **JSON Output**: Reliable structured output formatting

### Limitations

⚠️ **General Knowledge**: May be less knowledgeable about non-technical topics
⚠️ **Creative Writing**: Not optimized for prose or creative content
⚠️ **Model Size**: 4B is smaller than premium models (70B+)

## Best Practices

1. **Let Ollama Warm Up**: First query may be slow
2. **Monitor RAM Usage**: Close heavy applications during scans
3. **Use Dry-Run First**: Test before live execution
4. **Keep Model Updated**: Check for new versions periodically

```bash
# Check for updates
ollama list

# Update model
ollama pull ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q5_K_M
```

## Support

**Ollama Docs**: https://ollama.ai/
**Model Hub**: https://ollama.ai/library
**Qwen Documentation**: https://qwen.readthedocs.io/

---

*Updated for Ryoiki Tenkai v2.0 - Professional Edition*
