#!/usr/bin/env python3
"""
█▀█ █▄█ █▀█ █ █▄▀ █   ▀█▀ █▀▀ █▄ █ █▄▀ ▄▀█ █
█▀▄  █  █▄█ █ █ █ █    █  ██▄ █ ▀█ █ █ █▀█ █

Ryoiki Tenkai (領域展開) — Advanced Pentest Orchestration Agent
Professional Edition v2.0 - Sophisticated Terminal UI

FREE • OFFLINE • AUDITABLE • LAB-SAFE
"""

import os, sys, json, subprocess, re, requests, time, threading
from pathlib import Path
from typing import List, Dict, Optional, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
from urllib.parse import urlparse
from collections import defaultdict, deque
import hashlib

from rich.console import Console, Group
from rich.panel import Panel
from rich.prompt import Prompt, Confirm
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn, TaskID
from rich.table import Table
from rich.layout import Layout
from rich.live import Live
from rich.tree import Tree
from rich.syntax import Syntax
from rich.markdown import Markdown
from rich.align import Align
from rich.text import Text
from rich.columns import Columns
from rich import box
from rich.rule import Rule
from rich.status import Status

console = Console()

# ═══════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

class Config:
    """Global configuration"""
    MODEL = "ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q5_K_M"
    MAX_ITERATIONS = 50
    OLLAMA_URL = "http://localhost:11434/api/generate"
    
    DRY_RUN = True
    TERMINAL_TIMEOUT = 900
    
    BASE_WORKSPACE = Path.cwd().resolve()
    LOG_NAME = "agent.log"
    FINDINGS_DB = "findings.json"
    
    # UI Settings
    REFRESH_RATE = 10  # Updates per second
    MAX_LOG_LINES = 100
    SHOW_TIMESTAMPS = True
    ENABLE_ANIMATIONS = True

# ═══════════════════════════════════════════════════════════════════════════
# ENUMS & DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════

class Phase(Enum):
    RECON = "reconnaissance"
    ENUM = "enumeration"
    VULN = "vulnerability_analysis"
    EXPLOIT = "exploitation"
    POST = "post_exploitation"
    REPORT = "reporting"
    CTF = "ctf_mode"
    BUG_HUNT = "bug_bounty"

class ActionType(Enum):
    READ_FILE = "read_file"
    WRITE_FILE = "write_file"
    EXECUTE = "execute_command"
    LIST = "list_files"
    CODE_GEN = "generate_code"
    ANALYZE = "analyze_output"
    DONE = "done"

class ToolCategory(Enum):
    RECON = "🔍 Reconnaissance"
    ENUM = "📋 Enumeration"
    VULN = "🔓 Vulnerability Scanning"
    EXPLOIT = "💥 Exploitation"
    POST = "👑 Post-Exploitation"
    UTILITY = "🔧 Utility"

@dataclass
class Tool:
    name: str
    purpose: str
    phases: List[Phase]
    typical_usage: str
    category: ToolCategory
    output_format: str = "text"
    requires_target: bool = True

@dataclass
class Action:
    type: ActionType
    reasoning: str
    params: Dict
    metadata: Dict = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)

@dataclass
class Observation:
    success: bool
    output: str
    error: Optional[str] = None
    metadata: Dict = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    duration: float = 0.0

@dataclass
class Finding:
    severity: str
    title: str
    description: str
    evidence: str
    remediation: str
    cvss: Optional[float] = None
    cve: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.now)
    tool: str = "unknown"

@dataclass
class AgentStats:
    """Real-time agent statistics"""
    start_time: datetime = field(default_factory=datetime.now)
    iterations: int = 0
    commands_executed: int = 0
    files_created: int = 0
    files_read: int = 0
    code_generated: int = 0
    findings_discovered: int = 0
    current_phase: str = "Initializing"
    current_action: str = "Starting..."
    llm_tokens_used: int = 0
    errors_encountered: int = 0

# ═══════════════════════════════════════════════════════════════════════════
# COMPREHENSIVE TOOLKIT DATABASE
# ═══════════════════════════════════════════════════════════════════════════

PENTEST_TOOLKIT = {
    # Reconnaissance
    "nmap": Tool("nmap", "Network scanning and service detection", [Phase.RECON, Phase.ENUM],
                 "nmap -sV -sC -oN recon/nmap_scan.txt {target}", ToolCategory.RECON),
    "masscan": Tool("masscan", "Ultra-fast port scanner", [Phase.RECON],
                    "masscan {target} -p1-65535 --rate=1000 -oL recon/masscan.txt", ToolCategory.RECON),
    "amass": Tool("amass", "Subdomain enumeration and OSINT", [Phase.RECON],
                  "amass enum -passive -d {domain} -o recon/subdomains.txt", ToolCategory.RECON),
    "subfinder": Tool("subfinder", "Fast passive subdomain discovery", [Phase.RECON],
                      "subfinder -d {domain} -o recon/subfinder.txt", ToolCategory.RECON),
    "dnsenum": Tool("dnsenum", "DNS enumeration", [Phase.RECON],
                    "dnsenum {domain} --output recon/dns.txt", ToolCategory.RECON),
    "whois": Tool("whois", "Domain registration information", [Phase.RECON],
                  "whois {domain} > recon/whois.txt", ToolCategory.RECON),
    "theHarvester": Tool("theHarvester", "Email and subdomain harvesting", [Phase.RECON],
                         "theHarvester -d {domain} -b all -f recon/harvest", ToolCategory.RECON),
    
    # Web Enumeration
    "gobuster": Tool("gobuster", "Directory and file brute-forcing", [Phase.ENUM],
                     "gobuster dir -u {url} -w /usr/share/wordlists/dirb/common.txt -o enum/gobuster.txt", ToolCategory.ENUM),
    "ffuf": Tool("ffuf", "Fast web fuzzer", [Phase.ENUM],
                 "ffuf -u {url}/FUZZ -w /usr/share/wordlists/dirb/common.txt -o enum/ffuf.json", ToolCategory.ENUM),
    "dirsearch": Tool("dirsearch", "Web path scanner", [Phase.ENUM],
                      "dirsearch -u {url} -o enum/dirsearch.txt", ToolCategory.ENUM),
    "nikto": Tool("nikto", "Web server vulnerability scanner", [Phase.VULN],
                  "nikto -h {url} -output enum/nikto.txt", ToolCategory.VULN),
    "whatweb": Tool("whatweb", "Web technology fingerprinting", [Phase.ENUM],
                    "whatweb {url} -v > enum/whatweb.txt", ToolCategory.ENUM),
    "wpscan": Tool("wpscan", "WordPress vulnerability scanner", [Phase.VULN],
                   "wpscan --url {url} --enumerate ap,at,u -o enum/wpscan.txt", ToolCategory.VULN),
    "httpx": Tool("httpx", "HTTP toolkit for probing", [Phase.ENUM],
                  "httpx -list recon/subdomains.txt -o enum/httpx.txt", ToolCategory.ENUM),
    
    # Vulnerability Analysis
    "sqlmap": Tool("sqlmap", "SQL injection detection and exploitation", [Phase.VULN, Phase.EXPLOIT],
                   "sqlmap -u {url} --batch --output-dir=exploits/sqlmap", ToolCategory.VULN),
    "nuclei": Tool("nuclei", "Template-based vulnerability scanner", [Phase.VULN],
                   "nuclei -u {url} -o enum/nuclei.txt", ToolCategory.VULN),
    "wfuzz": Tool("wfuzz", "Web application fuzzer", [Phase.VULN],
                  "wfuzz -w /usr/share/wordlists/wfuzz/general/common.txt {url}/FUZZ", ToolCategory.VULN),
    
    # Exploitation
    "msfconsole": Tool("msfconsole", "Metasploit Framework console", [Phase.EXPLOIT, Phase.POST],
                       "msfconsole -q -x 'use {module}; set RHOSTS {target}; run'", ToolCategory.EXPLOIT, requires_target=False),
    "hydra": Tool("hydra", "Network login cracker", [Phase.EXPLOIT],
                  "hydra -L users.txt -P passwords.txt {protocol}://{target} -o exploits/hydra.txt", ToolCategory.EXPLOIT),
    
    # Password Cracking
    "john": Tool("john", "Password hash cracker", [Phase.EXPLOIT, Phase.POST],
                 "john --wordlist=/usr/share/wordlists/rockyou.txt {hashfile}", ToolCategory.POST, requires_target=False),
    "hashcat": Tool("hashcat", "Advanced password recovery", [Phase.EXPLOIT, Phase.POST],
                    "hashcat -m {mode} {hashfile} /usr/share/wordlists/rockyou.txt", ToolCategory.POST, requires_target=False),
    
    # Utilities
    "curl": Tool("curl", "HTTP client", [Phase.ENUM, Phase.VULN], "curl -v {url}", ToolCategory.UTILITY, requires_target=False),
    "wget": Tool("wget", "File downloader", [Phase.RECON], "wget {url}", ToolCategory.UTILITY, requires_target=False),
    "nc": Tool("nc", "Network swiss army knife", [Phase.EXPLOIT], "nc -lvnp {port}", ToolCategory.UTILITY, requires_target=False),
    "python3": Tool("python3", "Python interpreter", [Phase.EXPLOIT], "python3 {script}", ToolCategory.UTILITY, requires_target=False),
    "bash": Tool("bash", "Shell", [Phase.EXPLOIT], "bash {script}", ToolCategory.UTILITY, requires_target=False),
    
    # System
    "ls": Tool("ls", "List files", [], "ls -la", ToolCategory.UTILITY, requires_target=False),
    "cat": Tool("cat", "Read files", [], "cat {file}", ToolCategory.UTILITY, requires_target=False),
    "grep": Tool("grep", "Search text", [], "grep {pattern} {file}", ToolCategory.UTILITY, requires_target=False),
    "find": Tool("find", "Find files", [], "find {path} -name {pattern}", ToolCategory.UTILITY, requires_target=False),
    "chmod": Tool("chmod", "Change permissions", [], "chmod +x {file}", ToolCategory.UTILITY, requires_target=False),
    "whoami": Tool("whoami", "Current user", [], "whoami", ToolCategory.UTILITY, requires_target=False),
    "id": Tool("id", "User identity", [], "id", ToolCategory.UTILITY, requires_target=False),
    "pwd": Tool("pwd", "Current directory", [], "pwd", ToolCategory.UTILITY, requires_target=False),
}

ALLOWED_TOOLS = set(PENTEST_TOOLKIT.keys())

# ═══════════════════════════════════════════════════════════════════════════
# SECURITY & UTILITIES
# ═══════════════════════════════════════════════════════════════════════════

def sanitize_target(url: str) -> str:
    """Sanitize target URL for directory naming"""
    parsed = urlparse(url)
    netloc = parsed.netloc or parsed.path
    return re.sub(r'[^\w\-.]', '_', netloc)

def safe_path(base: Path, p: Path) -> Path:
    """Ensure path is within workspace"""
    resolved = p.resolve() if p.is_absolute() else (base / p).resolve()
    if not str(resolved).startswith(str(base)):
        raise PermissionError(f"Path escape attempt blocked: {p}")
    return resolved

def format_duration(seconds: float) -> str:
    """Format duration nicely"""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        return f"{int(seconds // 60)}m {int(seconds % 60)}s"
    else:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        return f"{hours}h {minutes}m"

def get_severity_color(severity: str) -> str:
    """Get color for severity"""
    colors = {
        "critical": "bold white on red",
        "high": "bold red",
        "medium": "bold yellow",
        "low": "bold blue",
        "info": "bold cyan"
    }
    return colors.get(severity.lower(), "white")

# ═══════════════════════════════════════════════════════════════════════════
# SOPHISTICATED UI COMPONENTS
# ═══════════════════════════════════════════════════════════════════════════

class UIComponents:
    """Advanced UI component generators"""
    
    @staticmethod
    def create_header(phase: str, target: Optional[str], stats: AgentStats) -> Panel:
        """Create sophisticated header panel"""
        elapsed = (datetime.now() - stats.start_time).total_seconds()
        
        # Create status grid
        grid = Table.grid(padding=(0, 2))
        grid.add_column(style="cyan", justify="right")
        grid.add_column(style="white")
        grid.add_column(style="cyan", justify="right")
        grid.add_column(style="white")
        
        grid.add_row(
            "Phase:", f"[bold yellow]{phase}[/]",
            "Target:", f"[bold green]{target or 'N/A'}[/]"
        )
        grid.add_row(
            "Iteration:", f"[bold]{stats.iterations}/{Config.MAX_ITERATIONS}[/]",
            "Elapsed:", f"[bold]{format_duration(elapsed)}[/]"
        )
        grid.add_row(
            "Commands:", f"[bold cyan]{stats.commands_executed}[/]",
            "Findings:", f"[bold red]{stats.findings_discovered}[/]"
        )
        
        title = Text()
        title.append("█▀█ █▄█ █▀█ █ █▄▀ █   ", style="bold magenta")
        title.append("▀█▀ █▀▀ █▄ █ █▄▀ ▄▀█ █", style="bold cyan")
        
        return Panel(
            Align.center(grid),
            title=title,
            border_style="cyan",
            box=box.DOUBLE
        )
    
    @staticmethod
    def create_status_panel(stats: AgentStats) -> Panel:
        """Create live status panel"""
        status_table = Table.grid(padding=(0, 1))
        status_table.add_column(style="dim")
        status_table.add_column()
        
        # Phase indicator
        phase_indicator = Text("●", style="bold green blink")
        status_table.add_row("Status:", Group(phase_indicator, Text(f" {stats.current_phase}", style="bold green")))
        
        # Current action
        status_table.add_row("Action:", Text(stats.current_action, style="cyan"))
        
        # Statistics
        status_table.add_row("", "")  # Spacer
        status_table.add_row("Files Created:", f"[green]{stats.files_created}[/]")
        status_table.add_row("Files Read:", f"[blue]{stats.files_read}[/]")
        status_table.add_row("Code Gen:", f"[magenta]{stats.code_generated}[/]")
        status_table.add_row("Errors:", f"[red]{stats.errors_encountered}[/]")
        
        return Panel(
            status_table,
            title="[bold cyan]⚡ Live Status[/bold cyan]",
            border_style="cyan",
            box=box.ROUNDED
        )
    
    @staticmethod
    def create_findings_panel(findings: List[Finding]) -> Panel:
        """Create findings tracker panel"""
        if not findings:
            return Panel(
                Align.center("[dim]No findings yet...[/dim]", vertical="middle"),
                title="[bold yellow]🎯 Findings[/bold yellow]",
                border_style="yellow",
                box=box.ROUNDED,
                height=10
            )
        
        # Group by severity
        severity_counts = defaultdict(int)
        for f in findings:
            severity_counts[f.severity.lower()] += 1
        
        # Create severity badges
        badges = []
        for severity in ["critical", "high", "medium", "low", "info"]:
            count = severity_counts.get(severity, 0)
            if count > 0:
                color = get_severity_color(severity)
                badge = Text(f" {severity.upper()}: {count} ", style=color)
                badges.append(badge)
        
        # Recent findings
        findings_table = Table(show_header=False, box=None, padding=(0, 1))
        findings_table.add_column("Time", style="dim", width=8)
        findings_table.add_column("Severity", width=10)
        findings_table.add_column("Title", style="white")
        
        for finding in findings[-5:]:  # Last 5
            time_str = finding.timestamp.strftime("%H:%M:%S")
            severity_badge = Text(finding.severity.upper()[:4], style=get_severity_color(finding.severity))
            title_truncated = finding.title[:40] + "..." if len(finding.title) > 40 else finding.title
            findings_table.add_row(time_str, severity_badge, title_truncated)
        
        content = Group(
            Columns(badges, padding=(0, 1)),
            Rule(style="dim"),
            findings_table
        )
        
        return Panel(
            content,
            title="[bold yellow]🎯 Findings[/bold yellow]",
            border_style="yellow",
            box=box.ROUNDED
        )
    
    @staticmethod
    def create_log_panel(log_buffer: deque) -> Panel:
        """Create scrolling log panel"""
        if not log_buffer:
            log_text = Text("[dim]Waiting for activity...[/dim]")
        else:
            log_lines = []
            for entry in log_buffer:
                timestamp = entry['time'].strftime("%H:%M:%S") if Config.SHOW_TIMESTAMPS else ""
                level = entry.get('level', 'INFO')
                message = entry['message']
                
                # Color by level
                level_colors = {
                    'INFO': 'cyan',
                    'SUCCESS': 'green',
                    'WARNING': 'yellow',
                    'ERROR': 'red',
                    'DEBUG': 'dim'
                }
                color = level_colors.get(level, 'white')
                
                if Config.SHOW_TIMESTAMPS:
                    line = Text()
                    line.append(f"[{timestamp}] ", style="dim")
                    line.append(f"[{level}] ", style=f"bold {color}")
                    line.append(message, style=color)
                else:
                    line = Text(message, style=color)
                
                log_lines.append(line)
            
            log_text = Group(*log_lines)
        
        return Panel(
            log_text,
            title="[bold green]📜 Activity Log[/bold green]",
            border_style="green",
            box=box.ROUNDED
        )
    
    @staticmethod
    def create_tool_panel(current_tool: Optional[str]) -> Panel:
        """Create current tool information panel"""
        if not current_tool or current_tool not in PENTEST_TOOLKIT:
            return Panel(
                Align.center("[dim]No tool active[/dim]", vertical="middle"),
                title="[bold magenta]🔧 Current Tool[/bold magenta]",
                border_style="magenta",
                box=box.ROUNDED,
                height=8
            )
        
        tool = PENTEST_TOOLKIT[current_tool]
        
        info = Table.grid(padding=(0, 1))
        info.add_column(style="cyan bold", justify="right")
        info.add_column(style="white")
        
        info.add_row("Tool:", f"[bold yellow]{tool.name}[/]")
        info.add_row("Category:", tool.category.value)
        info.add_row("Purpose:", tool.purpose)
        info.add_row("Output:", tool.output_format)
        
        return Panel(
            info,
            title="[bold magenta]🔧 Current Tool[/bold magenta]",
            border_style="magenta",
            box=box.ROUNDED
        )
    
    @staticmethod
    def create_workspace_tree(workspace: Path) -> Panel:
        """Create workspace file tree"""
        tree = Tree(
            f"[bold cyan]📁 {workspace.name}[/]",
            guide_style="dim"
        )
        
        def add_directory(parent_tree: Tree, path: Path, depth: int = 0):
            if depth > 2:  # Limit depth
                return
            
            try:
                items = sorted(path.iterdir(), key=lambda x: (not x.is_dir(), x.name))
                for item in items[:10]:  # Limit items
                    if item.is_dir():
                        branch = parent_tree.add(f"[bold blue]📁 {item.name}[/]")
                        add_directory(branch, item, depth + 1)
                    else:
                        size = item.stat().st_size
                        size_str = f"{size:,} bytes" if size < 1024 else f"{size/1024:.1f} KB"
                        parent_tree.add(f"[green]📄 {item.name}[/] [dim]({size_str})[/]")
            except PermissionError:
                parent_tree.add("[red]⚠ Permission denied[/]")
        
        add_directory(tree, workspace)
        
        return Panel(
            tree,
            title="[bold blue]📂 Workspace[/bold blue]",
            border_style="blue",
            box=box.ROUNDED
        )

# ═══════════════════════════════════════════════════════════════════════════
# ADVANCED TOOLKIT WITH PROGRESS TRACKING
# ═══════════════════════════════════════════════════════════════════════════

class AdvancedToolKit:
    """Toolkit with sophisticated progress tracking"""
    
    def __init__(self, workspace: Path, stats: AgentStats, log_buffer: deque):
        self.ws = workspace
        self.stats = stats
        self.log_buffer = log_buffer
        self.findings: List[Finding] = []
        self.current_tool: Optional[str] = None
        
    def log(self, message: str, level: str = "INFO"):
        """Add entry to log buffer"""
        self.log_buffer.append({
            'time': datetime.now(),
            'level': level,
            'message': message
        })
        
        # Keep buffer size manageable
        while len(self.log_buffer) > Config.MAX_LOG_LINES:
            self.log_buffer.popleft()
    
    def get_recommended_tools(self, phase: Phase) -> List[Tool]:
        """Get tools for phase"""
        return [tool for tool in PENTEST_TOOLKIT.values() if phase in tool.phases]
    
    def execute_command(self, cmd: str, phase: Optional[Phase] = None) -> Observation:
        """Execute command with progress tracking"""
        binary = cmd.strip().split()[0]
        
        if binary not in ALLOWED_TOOLS:
            self.log(f"⛔ Blocked command: {binary}", "ERROR")
            self.stats.errors_encountered += 1
            return Observation(
                success=False,
                output="",
                error=f"Command not allowed: {binary}"
            )
        
        self.current_tool = binary
        self.stats.current_action = f"Running {binary}..."
        self.log(f"⚡ Executing: {cmd}", "INFO")
        
        start_time = time.time()
        
        if Config.DRY_RUN:
            self.log(f"🔍 DRY RUN: {cmd}", "WARNING")
            tool_info = PENTEST_TOOLKIT.get(binary)
            duration = time.time() - start_time
            
            self.stats.commands_executed += 1
            
            return Observation(
                success=True,
                output=f"DRY RUN - Would execute: {cmd}",
                metadata={"dry_run": True, "tool": binary},
                duration=duration
            )
        
        # Real execution
        try:
            result = subprocess.run(
                cmd,
                shell=True,
                cwd=self.ws,
                capture_output=True,
                text=True,
                timeout=Config.TERMINAL_TIMEOUT
            )
            
            duration = time.time() - start_time
            output = result.stdout + result.stderr
            success = result.returncode == 0
            
            if success:
                self.log(f"✓ Completed in {format_duration(duration)}", "SUCCESS")
                self._parse_for_findings(binary, output)
                self.stats.commands_executed += 1
            else:
                self.log(f"✗ Failed (code {result.returncode})", "ERROR")
                self.stats.errors_encountered += 1
            
            return Observation(
                success=success,
                output=output,
                metadata={"returncode": result.returncode, "tool": binary},
                duration=duration
            )
            
        except subprocess.TimeoutExpired:
            duration = time.time() - start_time
            self.log(f"⏱ Timeout after {format_duration(duration)}", "ERROR")
            self.stats.errors_encountered += 1
            return Observation(
                success=False,
                output="",
                error=f"Command timed out",
                duration=duration
            )
        except Exception as e:
            duration = time.time() - start_time
            self.log(f"❌ Error: {str(e)}", "ERROR")
            self.stats.errors_encountered += 1
            return Observation(
                success=False,
                output="",
                error=str(e),
                duration=duration
            )
    
    def _parse_for_findings(self, tool: str, output: str):
        """Parse output for findings"""
        patterns = {
            "sql injection": ("high", "Potential SQL Injection"),
            "xss": ("medium", "Possible XSS Vulnerability"),
            "open port": ("info", "Open Port Detected"),
            "vulnerable": ("medium", "Vulnerability Found"),
            "exploit": ("high", "Exploitable Issue"),
        }
        
        for pattern, (severity, title) in patterns.items():
            if pattern.lower() in output.lower():
                finding = Finding(
                    severity=severity,
                    title=f"{title} ({tool})",
                    description=f"Detected by {tool}",
                    evidence=output[:500],
                    remediation="Review and validate finding manually",
                    tool=tool
                )
                self.findings.append(finding)
                self.stats.findings_discovered += 1
                self.log(f"🎯 Finding: {title} [{severity.upper()}]", "WARNING")
    
    def write_file(self, path: str, content: str) -> Observation:
        """Write file"""
        self.stats.current_action = f"Writing {path}..."
        self.log(f"💾 Writing file: {path}", "INFO")
        
        try:
            file_path = safe_path(self.ws, self.ws / path)
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(content, encoding="utf-8")
            
            self.stats.files_created += 1
            self.log(f"✓ Written: {path}", "SUCCESS")
            
            return Observation(
                success=True,
                output=f"Written to: {path} ({len(content)} bytes)",
                metadata={"path": str(file_path), "size": len(content)}
            )
        except Exception as e:
            self.log(f"❌ Write failed: {str(e)}", "ERROR")
            self.stats.errors_encountered += 1
            return Observation(success=False, output="", error=str(e))
    
    def read_file(self, path: str) -> Observation:
        """Read file"""
        self.stats.current_action = f"Reading {path}..."
        self.log(f"📖 Reading file: {path}", "INFO")
        
        try:
            file_path = safe_path(self.ws, self.ws / path)
            content = file_path.read_text(encoding="utf-8", errors="ignore")
            
            self.stats.files_read += 1
            self.log(f"✓ Read: {path} ({len(content)} bytes)", "SUCCESS")
            
            return Observation(
                success=True,
                output=content,
                metadata={"path": str(file_path), "size": len(content)}
            )
        except Exception as e:
            self.log(f"❌ Read failed: {str(e)}", "ERROR")
            self.stats.errors_encountered += 1
            return Observation(success=False, output="", error=str(e))
    
    def generate_code(self, language: str, purpose: str, code: str) -> Observation:
        """Generate code"""
        self.stats.current_action = f"Generating {language} code..."
        self.log(f"🔧 Generating {language} code: {purpose}", "INFO")
        
        extensions = {"python": "py", "bash": "sh", "ruby": "rb", "perl": "pl"}
        ext = extensions.get(language.lower(), "txt")
        filename = f"generated_{datetime.now().strftime('%Y%m%d_%H%M%S')}.{ext}"
        filepath = self.ws / "exploits" / filename
        
        try:
            filepath.parent.mkdir(exist_ok=True)
            filepath.write_text(code, encoding="utf-8")
            
            if ext in ["sh", "py", "rb", "pl"]:
                filepath.chmod(0o755)
            
            self.stats.code_generated += 1
            self.log(f"✓ Code generated: {filename}", "SUCCESS")
            
            return Observation(
                success=True,
                output=f"Code saved to: exploits/{filename}",
                metadata={"path": str(filepath), "language": language}
            )
        except Exception as e:
            self.log(f"❌ Code generation failed: {str(e)}", "ERROR")
            self.stats.errors_encountered += 1
            return Observation(success=False, output="", error=str(e))

# ═══════════════════════════════════════════════════════════════════════════
# SOPHISTICATED PENTEST AGENT WITH LIVE UI
# ═══════════════════════════════════════════════════════════════════════════

class SophisticatedPentestAgent:
    """Advanced agent with real-time UI"""
    
    def __init__(self, phase: Phase, target: Optional[str] = None):
        self.phase = phase
        self.target = target
        self.workspace = self._prepare_workspace()
        self.stats = AgentStats(current_phase=phase.value)
        self.log_buffer: deque = deque(maxlen=Config.MAX_LOG_LINES)
        self.toolkit = AdvancedToolKit(self.workspace, self.stats, self.log_buffer)
        self.history = []
        self.layout = self._create_layout()
        
    def _prepare_workspace(self) -> Path:
        """Create workspace"""
        if self.target:
            name = sanitize_target(self.target)
            ws = Config.BASE_WORKSPACE / "engagements" / name
        else:
            ws = Config.BASE_WORKSPACE / "workspace"
        
        for d in ["recon", "enum", "exploits", "reports", "loot", "screenshots"]:
            (ws / d).mkdir(parents=True, exist_ok=True)
        
        metadata = {
            "target": self.target,
            "phase": self.phase.value,
            "created": datetime.now().isoformat(),
        }
        (ws / "metadata.json").write_text(json.dumps(metadata, indent=2))
        
        return ws
    
    def _create_layout(self) -> Layout:
        """Create sophisticated split-panel layout"""
        layout = Layout()
        
        # Header
        layout.split_column(
            Layout(name="header", size=7),
            Layout(name="main", ratio=1)
        )
        
        # Main split into left and right
        layout["main"].split_row(
            Layout(name="left", ratio=2),
            Layout(name="right", ratio=1)
        )
        
        # Left split into output and log
        layout["left"].split_column(
            Layout(name="output", ratio=2),
            Layout(name="log", ratio=1)
        )
        
        # Right split into status, findings, and workspace
        layout["right"].split_column(
            Layout(name="status", size=12),
            Layout(name="findings", size=15),
            Layout(name="workspace", ratio=1)
        )
        
        return layout
    
    def _update_layout(self, current_output: Optional[Panel] = None):
        """Update all layout panels"""
        self.layout["header"].update(
            UIComponents.create_header(self.phase.value, self.target, self.stats)
        )
        self.layout["status"].update(
            UIComponents.create_status_panel(self.stats)
        )
        self.layout["findings"].update(
            UIComponents.create_findings_panel(self.toolkit.findings)
        )
        self.layout["log"].update(
            UIComponents.create_log_panel(self.log_buffer)
        )
        self.layout["workspace"].update(
            UIComponents.create_workspace_tree(self.workspace)
        )
        
        if current_output:
            self.layout["output"].update(current_output)
        else:
            self.layout["output"].update(
                Panel(
                    Align.center("[dim]Waiting for agent...[/dim]", vertical="middle"),
                    border_style="dim"
                )
            )
    
    def _build_system_prompt(self) -> str:
        """Build system prompt"""
        recommended_tools = self.toolkit.get_recommended_tools(self.phase)
        tool_list = "\n".join([
            f"  • {t.name}: {t.purpose}"
            for t in recommended_tools[:10]
        ])
        
        return f"""You are a professional penetration testing agent.

ENGAGEMENT:
- Phase: {self.phase.value.upper()}
- Target: {self.target or 'N/A'}
- Workspace: {self.workspace}

RECOMMENDED TOOLS FOR {self.phase.value.upper()}:
{tool_list}

RESPONSE FORMAT (JSON only):
{{
  "thinking": "Your analytical reasoning",
  "action": "execute_command|write_file|generate_code|read_file|done",
  "params": {{}},
  "done": false
}}

CAPABILITIES:
- Intelligent tool selection
- Code generation (Python, Bash, Ruby)
- Finding correlation
- Professional reporting

Be methodical, thorough, and document everything.
"""
    
    def _call_llm(self, prompt: str) -> str:
        """Call LLM"""
        self.stats.current_action = "Thinking..."
        self.toolkit.log("🧠 Querying LLM...", "INFO")
        
        try:
            response = requests.post(
                Config.OLLAMA_URL,
                json={
                    "model": Config.MODEL,
                    "prompt": prompt,
                    "stream": False
                },
                timeout=600
            )
            response.raise_for_status()
            result = response.json()["response"]
            
            self.toolkit.log("✓ LLM response received", "SUCCESS")
            return result
            
        except Exception as e:
            self.toolkit.log(f"❌ LLM error: {str(e)}", "ERROR")
            self.stats.errors_encountered += 1
            return ""
    
    def _parse_action(self, text: str) -> Optional[Action]:
        """Parse LLM response"""
        try:
            json_match = re.search(r'\{.*\}', text, re.DOTALL)
            if not json_match:
                return None
            
            data = json.loads(json_match.group())
            
            if data.get("done", False):
                return Action(
                    type=ActionType.DONE,
                    reasoning=data.get("thinking", "Task completed"),
                    params={}
                )
            
            return Action(
                type=ActionType(data["action"]),
                reasoning=data.get("thinking", ""),
                params=data.get("params", {})
            )
            
        except Exception as e:
            self.toolkit.log(f"⚠ Parse error: {str(e)}", "WARNING")
            return None
    
    def _create_action_panel(self, action: Action) -> Panel:
        """Create panel for action display"""
        # Reasoning
        reasoning = Markdown(action.reasoning)
        
        # Params
        if action.params:
            params_json = json.dumps(action.params, indent=2)
            params_display = Syntax(params_json, "json", theme="monokai", line_numbers=False)
        else:
            params_display = Text("[dim]No parameters[/dim]")
        
        # Action icon
        icons = {
            ActionType.EXECUTE: "⚡",
            ActionType.WRITE_FILE: "💾",
            ActionType.READ_FILE: "📖",
            ActionType.CODE_GEN: "🔧",
            ActionType.DONE: "✅"
        }
        icon = icons.get(action.type, "▶️")
        
        content = Group(
            Panel(reasoning, title="[bold cyan]🧠 Reasoning[/]", border_style="cyan", box=box.SIMPLE),
            Panel(params_display, title="[bold yellow]📋 Parameters[/]", border_style="yellow", box=box.SIMPLE)
        )
        
        return Panel(
            content,
            title=f"[bold]{icon} {action.type.value.replace('_', ' ').title()}[/]",
            border_style="green",
            box=box.DOUBLE
        )
    
    def _create_observation_panel(self, obs: Observation) -> Panel:
        """Create panel for observation display"""
        if obs.success:
            # Truncate long output
            output = obs.output
            if len(output) > 1000:
                output = output[:500] + "\n\n... [truncated] ...\n\n" + output[-500:]
            
            content = Text(output, style="green")
            title = f"[bold green]✓ Output[/] [dim]({format_duration(obs.duration)})[/]"
            border_style = "green"
        else:
            content = Text(obs.error or "Unknown error", style="red")
            title = f"[bold red]✗ Error[/] [dim]({format_duration(obs.duration)})[/]"
            border_style = "red"
        
        return Panel(
            content,
            title=title,
            border_style=border_style,
            box=box.ROUNDED
        )
    
    def _execute_action(self, action: Action) -> Observation:
        """Execute action"""
        try:
            if action.type == ActionType.EXECUTE:
                return self.toolkit.execute_command(
                    action.params.get("command", ""),
                    self.phase
                )
            elif action.type == ActionType.WRITE_FILE:
                return self.toolkit.write_file(
                    action.params.get("path", ""),
                    action.params.get("content", "")
                )
            elif action.type == ActionType.READ_FILE:
                return self.toolkit.read_file(action.params.get("path", ""))
            elif action.type == ActionType.CODE_GEN:
                return self.toolkit.generate_code(
                    action.params.get("language", "python"),
                    action.params.get("purpose", ""),
                    action.params.get("code", "")
                )
            else:
                return Observation(False, "", f"Unknown action: {action.type}")
        except Exception as e:
            return Observation(False, "", str(e))
    
    def run(self):
        """Main execution with live UI"""
        # Initialize
        self.history.append({
            "role": "system",
            "content": self._build_system_prompt()
        })
        
        self.toolkit.log("🚀 Agent initialized", "INFO")
        self.toolkit.log(f"📍 Phase: {self.phase.value}", "INFO")
        self.toolkit.log(f"🎯 Target: {self.target or 'N/A'}", "INFO")
        
        try:
            with Live(self.layout, refresh_per_second=Config.REFRESH_RATE, console=console) as live:
                for iteration in range(1, Config.MAX_ITERATIONS + 1):
                    self.stats.iterations = iteration
                    self.stats.current_phase = f"{self.phase.value} - Iteration {iteration}"
                    
                    # Update UI
                    self._update_layout()
                    time.sleep(0.1)  # Brief pause for visual update
                    
                    # Build prompt
                    prompt = "\n\n".join([
                        f"{m['role'].upper()}: {m['content']}"
                        for m in self.history
                    ])
                    
                    # Get LLM response
                    response = self._call_llm(prompt)
                    if not response:
                        self.toolkit.log("⚠ Empty LLM response", "WARNING")
                        break
                    
                    # Parse action
                    action = self._parse_action(response)
                    if not action:
                        self.toolkit.log("⚠ Failed to parse action", "WARNING")
                        self.history.append({"role": "assistant", "content": response})
                        self.history.append({"role": "user", "content": "ERROR: Invalid JSON"})
                        continue
                    
                    # Display action
                    action_panel = self._create_action_panel(action)
                    self._update_layout(action_panel)
                    time.sleep(0.5)  # Pause to show action
                    
                    # Check if done
                    if action.type == ActionType.DONE:
                        self.toolkit.log("✅ Agent completed task", "SUCCESS")
                        self._update_layout(
                            Panel(
                                Align.center("[bold green]✓ ENGAGEMENT COMPLETE[/]", vertical="middle"),
                                border_style="green",
                                box=box.DOUBLE
                            )
                        )
                        time.sleep(2)
                        break
                    
                    # Execute action
                    obs = self._execute_action(action)
                    
                    # Display observation
                    obs_panel = self._create_observation_panel(obs)
                    self._update_layout(obs_panel)
                    time.sleep(0.5)
                    
                    # Update history
                    self.history.append({"role": "assistant", "content": response})
                    self.history.append({"role": "user", "content": obs.output or obs.error or ""})
                
                # Final update
                self._update_layout()
                time.sleep(1)
                
        except KeyboardInterrupt:
            self.toolkit.log("⚠ Interrupted by user", "WARNING")
        except Exception as e:
            self.toolkit.log(f"❌ Fatal error: {str(e)}", "ERROR")
            import traceback
            traceback.print_exc()
        
        # Generate final report
        self._generate_report()
    
    def _generate_report(self):
        """Generate final report"""
        console.print("\n")
        console.print(Rule("[bold cyan]Final Report[/]"))
        
        # Summary table
        summary = Table(title="Engagement Summary", box=box.ROUNDED)
        summary.add_column("Metric", style="cyan")
        summary.add_column("Value", style="white")
        
        elapsed = (datetime.now() - self.stats.start_time).total_seconds()
        summary.add_row("Duration", format_duration(elapsed))
        summary.add_row("Iterations", str(self.stats.iterations))
        summary.add_row("Commands Executed", str(self.stats.commands_executed))
        summary.add_row("Files Created", str(self.stats.files_created))
        summary.add_row("Code Generated", str(self.stats.code_generated))
        summary.add_row("Findings", str(self.stats.findings_discovered))
        summary.add_row("Errors", str(self.stats.errors_encountered))
        
        console.print(summary)
        
        # Findings by severity
        if self.toolkit.findings:
            console.print("\n")
            findings_table = Table(title="Findings by Severity", box=box.ROUNDED)
            findings_table.add_column("Severity", style="bold")
            findings_table.add_column("Count", justify="right")
            findings_table.add_column("Percentage", justify="right")
            
            severity_counts = defaultdict(int)
            for f in self.toolkit.findings:
                severity_counts[f.severity.lower()] += 1
            
            total = len(self.toolkit.findings)
            for severity in ["critical", "high", "medium", "low", "info"]:
                count = severity_counts.get(severity, 0)
                if count > 0:
                    pct = (count / total) * 100
                    findings_table.add_row(
                        Text(severity.upper(), style=get_severity_color(severity)),
                        str(count),
                        f"{pct:.1f}%"
                    )
            
            console.print(findings_table)
        
        # Save report
        report_path = self.workspace / "reports" / f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
        # ... (report generation code)
        
        console.print(f"\n[green]✓[/] Report saved to: {report_path}\n")

# ═══════════════════════════════════════════════════════════════════════════
# MAIN CLI
# ═══════════════════════════════════════════════════════════════════════════

def main():
    """Main entry point"""
    console.clear()
    
    # Splash screen
    splash = Panel(
        Align.center(f"""[bold magenta]
    ██████╗ ██╗   ██╗ ██████╗ ██╗██╗  ██╗██╗
    ██╔══██╗╚██╗ ██╔╝██╔═══██╗██║██║ ██╔╝██║
    ██████╔╝ ╚████╔╝ ██║   ██║██║█████╔╝ ██║
    ██╔══██╗  ╚██╔╝  ██║   ██║██║██╔═██╗ ██║
    ██║  ██║   ██║   ╚██████╔╝██║██║  ██╗██║
    ╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚═╝╚═╝  ╚═╝╚═╝
    
    [cyan]▀█▀ █▀▀ █▄ █ █▄▀ ▄▀█ █[/]  Professional Edition v2.0
    [cyan] █  ██▄ █ ▀█ █ █ █▀█ █[/]  Sophisticated Terminal UI
[/bold magenta]

[dim]Advanced Penetration Testing Orchestration Agent[/]
[dim]FREE • OFFLINE • AUDITABLE • LAB-SAFE[/]
"""),
        border_style="cyan",
        box=box.DOUBLE
    )
    console.print(splash)
    console.print()
    
    # Phase selection
    console.print("[bold cyan]Select Engagement Phase:[/bold cyan]")
    phase_choice = Prompt.ask(
        "Phase",
        choices=["recon", "enum", "vuln", "exploit", "post", "report", "ctf", "bug_hunt"],
        default="recon"
    )
    
    phase_map = {
        "recon": Phase.RECON,
        "enum": Phase.ENUM,
        "vuln": Phase.VULN,
        "exploit": Phase.EXPLOIT,
        "post": Phase.POST,
        "report": Phase.REPORT,
        "ctf": Phase.CTF,
        "bug_hunt": Phase.BUG_HUNT
    }
    
    phase = phase_map[phase_choice]
    
    # Target input
    target = None
    if phase in [Phase.RECON, Phase.ENUM, Phase.VULN, Phase.EXPLOIT, Phase.CTF, Phase.BUG_HUNT]:
        target = Prompt.ask("\n[bold yellow]🎯 Target[/bold yellow] (URL/IP)")
        
        if not Confirm.ask(f"\n⚠️  Confirm authorization for: [bold]{target}[/bold]", default=False):
            console.print("[red]Authorization not confirmed - exiting[/red]")
            return
    
    console.print()
    if not Confirm.ask("▶️  Launch agent with live UI?", default=True):
        return
    
    console.clear()
    
    # Run agent
    try:
        agent = SophisticatedPentestAgent(phase, target)
        agent.run()
    except Exception as e:
        console.print(f"\n[bold red]Fatal Error:[/] {str(e)}")
        import traceback
        console.print(traceback.format_exc())

if __name__ == "__main__":
    main()
