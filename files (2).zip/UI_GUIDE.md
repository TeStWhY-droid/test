# Ryoiki Tenkai - Sophisticated UI Guide

## 🎨 Ultimate Terminal Interface

This version features a Claude Code-inspired split-panel interface with real-time updates, live statistics, and professional visualization.

---

## 📐 Interface Layout

```
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
║  █▀█ █▄█ █▀█ █ █▄▀ █   ▀█▀ █▀▀ █▄ █ █▄▀ ▄▀█ █                         ║
║                                                                        ║
║  Phase: RECONNAISSANCE    Target: example.com                         ║
║  Iteration: 15/50         Elapsed: 3m 45s                            ║
║  Commands: 8              Findings: 3                                 ║
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
║                             ║  ⚡ Live Status                         ║
║                             ║  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ║
║                             ║  Status: ● Running nmap                 ║
║                             ║  Action: Scanning ports...              ║
║                             ║                                         ║
║   🧠 Reasoning              ║  Files Created: 5                       ║
║   ─────────────────         ║  Files Read: 3                          ║
║                             ║  Code Gen: 1                            ║
║   I will perform a          ║  Errors: 0                              ║
║   comprehensive port        ┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
║   scan to identify          ║  🎯 Findings                            ║
║   running services...       ║  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ║
║                             ║                                         ║
║                             ║  CRITICAL: 0  HIGH: 1  MEDIUM: 2       ║
║   📋 Parameters             ║  ─────────────────────────────────────  ║
║   ─────────────────         ║  14:23:01  HIGH  SQL Injection...      ║
║   {                         ║  14:25:33  MED   XSS Vulnerability     ║
║     "command": "nmap..."    ║  14:27:12  MED   Open Directory        ║
║   }                         ║                                         ║
║                             ┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫  📂 Workspace                           ║
║  📜 Activity Log            ║  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ║
║  ━━━━━━━━━━━━━━━━━━━━━━━━  ║  📁 example.com                         ║
║                             ║    📁 recon                             ║
║  [14:23:00] [INFO] ⚡       ║      📄 nmap_scan.txt (15KB)           ║
║  Executing: nmap...         ║      📄 subdomains.txt (8KB)           ║
║                             ║    📁 enum                              ║
║  [14:23:45] [SUCCESS] ✓     ║      📄 gobuster.txt (42KB)            ║
║  Completed in 45.2s         ║    📁 exploits                          ║
║                             ║      📄 exploit.py (2KB)                ║
║  [14:24:01] [INFO] 🎯       ║    📁 reports                           ║
║  Finding: SQL Injection     ║                                         ║
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┻━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
```

---

## 🎯 Interface Panels

### 1. Header Panel (Top)
**Location**: Top of screen  
**Updates**: Every second  
**Shows**:
- Current phase with color coding
- Target information
- Iteration progress (X/50)
- Elapsed time
- Commands executed counter
- Findings discovered counter

**Features**:
- Double-line border for prominence
- Cyan theme matching Ryoiki branding
- Condensed statistics grid
- Real-time updating values

---

### 2. Main Output Panel (Center-Left, Top)
**Location**: Left side, upper section (60% height)  
**Updates**: On each action/observation  
**Shows**:
- Current agent reasoning (markdown formatted)
- Action parameters (JSON with syntax highlighting)
- Command outputs
- Error messages

**Features**:
- Large display area for detailed content
- Markdown rendering for reasoning
- Syntax highlighting for code/JSON
- Color-coded success (green) / error (red) borders
- Auto-truncation of long outputs

---

### 3. Activity Log Panel (Center-Left, Bottom)
**Location**: Left side, lower section (40% height)  
**Updates**: Real-time as events occur  
**Shows**:
- Timestamped log entries
- Log level indicators (INFO, SUCCESS, ERROR, WARNING)
- Recent agent activities
- Scrolling buffer (last 100 lines)

**Features**:
- Color-coded by log level:
  - INFO: cyan
  - SUCCESS: green
  - WARNING: yellow
  - ERROR: red
  - DEBUG: dim
- Timestamps (HH:MM:SS format)
- Auto-scrolling
- Icon indicators (⚡, ✓, ❌, 🎯, etc.)

---

### 4. Live Status Panel (Right, Top)
**Location**: Right side, top section  
**Updates**: Every 100ms  
**Shows**:
- Animated status indicator (●)
- Current phase name
- Current action description
- File operations counters
- Code generation counter
- Error counter

**Features**:
- Blinking green dot for activity
- Real-time action updates
- Statistics grid
- Compact format

---

### 5. Findings Panel (Right, Middle)
**Location**: Right side, middle section  
**Updates**: When new findings discovered  
**Shows**:
- Severity badges (CRITICAL, HIGH, MEDIUM, LOW, INFO)
- Counts by severity level
- Recent findings (last 5)
- Timestamps
- Truncated titles

**Features**:
- Color-coded severity:
  - CRITICAL: White on red, bold
  - HIGH: Red, bold
  - MEDIUM: Yellow, bold
  - LOW: Blue, bold
  - INFO: Cyan, bold
- Severity summary badges at top
- Chronological listing
- Quick visual scanning

---

### 6. Workspace Tree Panel (Right, Bottom)
**Location**: Right side, bottom section  
**Updates**: Periodically (every 5 seconds)  
**Shows**:
- Directory tree structure
- File names with icons
- File sizes
- Nested directories (up to 2 levels)

**Features**:
- Folder icons (📁)
- File icons (📄)
- File size display
- Hierarchical tree view
- Color coding (directories: blue, files: green)
- Limit of 10 items per directory

---

## 🔄 Real-Time Updates

### Update Frequency
- **Header**: 1 second refresh
- **Status**: 10 Hz (100ms)
- **Log**: Real-time append
- **Findings**: On discovery
- **Workspace**: 5 second polling
- **Output**: On action completion

### Performance
- Efficient rendering using Rich's Live display
- Minimal CPU overhead (~5%)
- Smooth animations
- No flickering

---

## 🎨 Color Scheme

### Primary Colors
- **Cyan**: Branding, headers, info
- **Green**: Success, completion, active status
- **Yellow**: Warnings, medium findings, target info
- **Red**: Errors, critical findings, failures
- **Blue**: Files, directories, low findings
- **Magenta**: Tools, code generation

### Severity Colors
```python
CRITICAL: "bold white on red"    # ⚠️ Highest priority
HIGH:     "bold red"              # 🔴 Serious issues
MEDIUM:   "bold yellow"           # 🟡 Notable concerns
LOW:      "bold blue"             # 🔵 Minor issues
INFO:     "bold cyan"             # ℹ️ Informational
```

### UI Element Colors
```python
Headers:      "cyan"
Borders:      "cyan" (default), "green" (success), "red" (error)
Log Levels:   INFO=cyan, SUCCESS=green, WARNING=yellow, ERROR=red
Status Dot:   "bold green blink"
Timestamps:   "dim"
```

---

## ⌨️ Keyboard Controls

### During Execution
- **Ctrl+C**: Graceful shutdown with report generation
- **Ctrl+Z**: Pause (not recommended - may corrupt state)

### Interactive Prompts
- **Enter**: Confirm default choice
- **Y/N**: Yes/No prompts
- **Arrow Keys**: Not supported (prompt-based input)

---

## 📊 Statistics Tracking

### Real-Time Metrics
```python
class AgentStats:
    start_time: datetime          # Engagement start
    iterations: int               # Current iteration (X/50)
    commands_executed: int        # Total commands run
    files_created: int           # Files written
    files_read: int              # Files accessed
    code_generated: int          # Scripts created
    findings_discovered: int     # Vulnerabilities found
    errors_encountered: int      # Errors logged
    current_phase: str           # Display phase name
    current_action: str          # What agent is doing now
```

### Calculated Metrics
- **Elapsed Time**: Formatted as "Xh Ym Zs" or "Xm Ys" or "X.Ys"
- **Success Rate**: (commands - errors) / commands
- **Findings Rate**: findings / iteration
- **Action Duration**: Time per command execution

---

## 🎬 Animation Features

### Animated Elements
1. **Status Indicator**: Blinking green dot (●)
2. **Progress Bars**: Smooth filling for long operations
3. **Spinners**: During LLM queries
4. **Transitions**: Smooth panel updates

### Configuration
```python
ENABLE_ANIMATIONS = True   # Master toggle
REFRESH_RATE = 10         # Updates per second
```

Set `ENABLE_ANIMATIONS = False` for:
- Screen recordings
- Low-end terminals
- SSH over slow connections

---

## 🖥️ Terminal Requirements

### Minimum Requirements
- **Width**: 120 columns
- **Height**: 30 rows
- **Colors**: 256-color support
- **Unicode**: UTF-8 encoding

### Recommended
- **Width**: 140+ columns
- **Height**: 40+ rows
- **Colors**: True color (24-bit)
- **Terminal**: iTerm2, Windows Terminal, Kitty, Alacritty

### Terminal Compatibility
✅ **Excellent**:
- iTerm2 (macOS)
- Windows Terminal
- Kitty
- Alacritty
- Hyper

✅ **Good**:
- GNOME Terminal
- Konsole
- Terminator
- tmux

⚠️ **Limited**:
- PuTTY (Windows)
- Basic Terminal.app
- Screen
- Old xterm

---

## 🎯 UI Components Deep Dive

### 1. Progress Indicators
```python
# Built-in Rich Progress for long operations
progress = Progress(
    SpinnerColumn(),
    TextColumn("[cyan]Scanning..."),
    BarColumn(),
    TimeElapsedColumn()
)
```

**Used for**:
- Port scanning (nmap, masscan)
- Directory brute-forcing (gobuster, ffuf)
- Hash cracking (john, hashcat)
- Large file operations

### 2. Tree Views
```python
# Workspace tree with icons and colors
tree = Tree("📁 example.com", guide_style="dim")
tree.add("📁 recon")
tree.add("📄 nmap_scan.txt [dim](15KB)[/]")
```

**Features**:
- Collapsible (manual - view depth limited)
- Size information
- Type indicators
- Color coding

### 3. Tables
```python
# Statistics and findings tables
table = Table(box=box.ROUNDED)
table.add_column("Metric", style="cyan")
table.add_column("Value", style="white")
```

**Used for**:
- Final reports
- Statistics summaries
- Finding listings
- Tool recommendations

### 4. Syntax Highlighting
```python
# Code and JSON display
syntax = Syntax(code, "python", theme="monokai", line_numbers=True)
```

**Supported**:
- Python
- Bash
- JSON
- Ruby
- Perl
- JavaScript

---

## 🔧 Customization

### Colors
Edit `UIComponents` class methods to change colors:
```python
# Change header style
title = Text()
title.append("RYOIKI TENKAI", style="bold red")  # Was magenta
```

### Layout
Modify `_create_layout()` ratios:
```python
# Make output bigger, log smaller
layout["left"].split_column(
    Layout(name="output", ratio=3),  # Was 2
    Layout(name="log", ratio=1)
)
```

### Refresh Rate
```python
Config.REFRESH_RATE = 5  # Slower (5 Hz)
Config.REFRESH_RATE = 20 # Faster (20 Hz)
```

### Log Buffer
```python
Config.MAX_LOG_LINES = 200  # Keep more history
```

---

## 📸 Screenshot Modes

### Full Interface
```bash
# Capture entire screen
./ryoiki_tenkai_ultimate.py
# Take screenshot with terminal app
```

### Specific Panels
The split-panel design allows capturing individual sections:
- Header only: Engagement metadata
- Output panel: Agent reasoning
- Findings panel: Vulnerability summary
- Workspace panel: File structure

---

## 🎓 Pro Tips

### 1. Terminal Size
```bash
# Check your terminal size
tput cols  # Width (need 120+)
tput lines # Height (need 30+)

# Resize terminal
printf '\033[8;40;140t'  # 40 rows, 140 cols
```

### 2. Font Recommendations
- **Monospace**: Required
- **Ligatures**: Optional but nice
- **Recommended fonts**:
  - Fira Code
  - JetBrains Mono
  - Cascadia Code
  - Inconsolata

### 3. tmux/screen Integration
```bash
# In tmux
tmux new-session -s ryoiki
./ryoiki_tenkai_ultimate.py

# Detach: Ctrl+B, D
# Reattach: tmux attach -t ryoiki
```

### 4. Recording Sessions
```bash
# Using asciinema
asciinema rec ryoiki-session.cast
./ryoiki_tenkai_ultimate.py
# Ctrl+D to stop

# Using script
script -t 2>timing.txt -a output.txt
./ryoiki_tenkai_ultimate.py
```

---

## 🐛 Troubleshooting

### Issue: Layout Broken
**Cause**: Terminal too small  
**Fix**:
```bash
# Resize to minimum 120x30
resize -s 40 140
```

### Issue: Colors Wrong
**Cause**: Terminal doesn't support true color  
**Fix**: Use a modern terminal emulator

### Issue: Unicode Broken
**Cause**: Wrong encoding  
**Fix**:
```bash
export LANG=en_US.UTF-8
export LC_ALL=en_US.UTF-8
```

### Issue: Flickering
**Cause**: Refresh rate too high or terminal lag  
**Fix**: Lower refresh rate in Config

### Issue: CPU High
**Cause**: Too many updates  
**Fix**:
```python
Config.REFRESH_RATE = 5  # Lower from 10
Config.ENABLE_ANIMATIONS = False
```

---

## 🎬 Demo Mode

### Quick Test
```bash
# Run in dry-run mode with dummy data
Config.DRY_RUN = True

# Select CTF mode for faster demonstration
./ryoiki_tenkai_ultimate.py
> Phase: ctf
> Target: 10.10.10.100
```

### Screenshot Preparation
1. Clear terminal: `clear`
2. Resize: 140x40
3. Set theme: Dark background
4. Hide menu bars
5. Start agent
6. Wait for interesting state
7. Capture

---

## 🚀 Performance Optimization

### For Low-End Systems
```python
Config.REFRESH_RATE = 2
Config.MAX_LOG_LINES = 50
Config.ENABLE_ANIMATIONS = False
Config.SHOW_TIMESTAMPS = False
```

### For High-End Systems
```python
Config.REFRESH_RATE = 20
Config.MAX_LOG_LINES = 200
Config.ENABLE_ANIMATIONS = True
```

### For Remote SSH
```python
Config.REFRESH_RATE = 1  # Very slow
Config.ENABLE_ANIMATIONS = False
```

---

## 📚 Comparison: Standard vs Ultimate UI

| Feature | Standard | Ultimate |
|---------|----------|----------|
| Layout | Single panel | Split 6-panel |
| Updates | Manual | Real-time (10Hz) |
| Statistics | End only | Live tracking |
| Findings | Text list | Visual tracker |
| Workspace | N/A | Live tree |
| Logs | Console | Scrolling panel |
| Colors | Basic | Full palette |
| Animations | None | Multiple |
| Progress | Text | Visual bars |
| Customization | Limited | Extensive |

---

## 🎉 Conclusion

The Ultimate UI transforms Ryoiki Tenkai from a command-line tool into a professional penetration testing workstation with:

✅ Real-time visual feedback  
✅ Professional appearance  
✅ Comprehensive monitoring  
✅ Efficient information density  
✅ Production-ready interface  

Perfect for:
- Professional engagements
- Client demonstrations
- Training and education
- Team collaboration
- Report generation

**Experience the future of terminal-based penetration testing!**

---

*Ryoiki Tenkai Ultimate - Where sophistication meets security*
