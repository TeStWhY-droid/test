# Ryoiki Tenkai (領域展開) - Professional Edition

<div align="center">

```
    ██████╗ ██╗   ██╗ ██████╗ ██╗██╗  ██╗██╗
    ██╔══██╗╚██╗ ██╔╝██╔═══██╗██║██║ ██╔╝██║
    ██████╔╝ ╚████╔╝ ██║   ██║██║█████╔╝ ██║
    ██╔══██╗  ╚██╔╝  ██║   ██║██║██╔═██╗ ██║
    ██║  ██║   ██║   ╚██████╔╝██║██║  ██╗██║
    ╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚═╝╚═╝  ╚═╝╚═╝
    
    ▀█▀ █▀▀ █▄ █ █▄▀ ▄▀█ █
     █  ██▄ █ ▀█ █ █ █▀█ █
```

**Advanced Penetration Testing Orchestration Agent**

[![Kali Linux](https://img.shields.io/badge/Platform-Kali_Linux-557C94?style=for-the-badge&logo=kalilinux)](https://www.kali.org/)
[![Python 3.8+](https://img.shields.io/badge/Python-3.8+-3776AB?style=for-the-badge&logo=python)](https://www.python.org/)
[![Ollama](https://img.shields.io/badge/LLM-Ollama-000000?style=for-the-badge)](https://ollama.ai/)
[![License](https://img.shields.io/badge/License-MIT-green.svg?style=for-the-badge)](LICENSE)

**FREE** • **OFFLINE** • **AUDITABLE** • **LAB-SAFE**

</div>

---

## 🎯 Overview

**Ryoiki Tenkai** is a sophisticated AI-powered penetration testing framework designed for Kali Linux. It combines intelligent tool selection, automated code generation, and professional reporting into a unified agent that assists security professionals throughout the entire pentest lifecycle.

### ✨ Key Features

#### 🧠 Intelligent Automation
- **Smart Tool Selection**: Automatically chooses optimal Kali tools for each phase
- **Tool Chaining**: Sequences multiple tools for comprehensive coverage
- **Output Correlation**: Parses and links findings across different tools

#### 🔧 Advanced Code Generation
- Generate custom exploits in Python, Bash, Ruby, Perl
- Create enumeration scripts on-the-fly
- Build proof-of-concept payloads
- Automated script permissions and organization

#### 📊 Professional Reporting
- Severity-based finding classification (Critical → Info)
- Executive summaries with CVSS scoring
- Evidence collection and timestamping
- Actionable remediation recommendations
- Markdown and HTML report generation

#### 🎨 Beautiful Terminal UI
- Rich, colorful interface with panels and tables
- Real-time progress indicators
- Structured output formatting
- Interactive prompts and confirmations

#### 🛡️ Security First
- Sandboxed execution environment
- Command allowlisting (Kali tools only)
- Path traversal prevention
- Dry-run mode for safe testing
- Authorization confirmations

---

## 🚀 Installation

### Prerequisites

1. **Kali Linux** (2023.1 or later)
2. **Python 3.8+**
3. **Ollama** with a code model

### Step 1: Install Dependencies

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Python dependencies
pip install rich requests

# Install Ollama (if not already installed)
curl -fsSL https://ollama.ai/install.sh | sh
```

### Step 2: Download Ollama Model

```bash
# Download the recommended model
ollama pull ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q5_K_M

# Alternative: Standard Qwen models
ollama pull qwen2.5-coder:7b
ollama pull qwen2.5-coder:14b
```

### Step 3: Install Ryoiki Tenkai

```bash
# Clone or download the script
chmod +x ryoiki_tenkai_pro.py

# Optional: Create symlink for easy access
sudo ln -s $(pwd)/ryoiki_tenkai_pro.py /usr/local/bin/ryoiki

# Run from anywhere
ryoiki
```

### Step 4: Start Ollama Server

```bash
# Start Ollama in background
ollama serve &

# Verify it's running
curl http://localhost:11434/api/tags
```

---

## 📖 Usage

### Basic Usage

```bash
# Run with interactive prompts
./ryoiki_tenkai_pro.py

# Or if you created the symlink
ryoiki
```

### Engagement Phases

The agent operates in different phases aligned with the pentest methodology:

| Phase | Description | Typical Tools |
|-------|-------------|---------------|
| **RECON** | Information gathering and OSINT | nmap, amass, subfinder, whois |
| **ENUM** | Service and application enumeration | gobuster, nikto, whatweb, ffuf |
| **VULN** | Vulnerability identification | nuclei, sqlmap, wpscan |
| **EXPLOIT** | Active exploitation | metasploit, hydra, custom exploits |
| **POST** | Post-exploitation activities | john, hashcat, privilege escalation |
| **REPORT** | Report generation and documentation | - |
| **CTF** | CTF competition mode (aggressive) | All tools, flag-focused |
| **BUG_HUNT** | Bug bounty methodology | Comprehensive scanning + reporting |

### Example Workflows

#### 1. Web Application Pentest

```bash
# Phase 1: Reconnaissance
./ryoiki_tenkai_pro.py
> Select phase: recon
> Target: https://example.com

# The agent will:
# - Run subdomain enumeration (amass, subfinder)
# - Port scan discovered hosts (nmap)
# - Fingerprint web technologies (whatweb, httpx)
# - Save all outputs to engagements/example.com/recon/
```

#### 2. CTF Challenge

```bash
./ryoiki_tenkai_pro.py
> Select phase: ctf
> Target: 10.10.10.100

# The agent will:
# - Perform aggressive enumeration
# - Look for common CTF patterns
# - Attempt common exploits
# - Search for flags in outputs
```

#### 3. Bug Bounty Hunt

```bash
./ryoiki_tenkai_pro.py
> Select phase: bug_hunt
> Target: https://target.example.com

# The agent will:
# - Comprehensive subdomain discovery
# - Technology fingerprinting
# - Vulnerability scanning
# - Generate detailed report with severity ratings
# - Provide PoC for each finding
```

### Code Generation Examples

The agent can generate custom code on demand:

```python
# Example: Custom port scanner
{
  "action": "generate_code",
  "params": {
    "language": "python",
    "purpose": "Multi-threaded port scanner for top 1000 ports",
    "code": "#!/usr/bin/env python3\nimport socket\n..."
  }
}
```

```bash
# Example: Parsing script
{
  "action": "generate_code",
  "params": {
    "language": "bash",
    "purpose": "Parse nmap output and extract open ports",
    "code": "#!/bin/bash\ngrep -oP '\\d+/open' nmap.txt..."
  }
}
```

---

## ⚙️ Configuration

Edit the `Config` class in `ryoiki_tenkai_pro.py`:

```python
class Config:
    # LLM Settings
    MODEL = "ertghiu256/Qwen3-4b-tcomanr-merge-v2.5:Q5_K_M"  # Ollama model
    OLLAMA_URL = "http://localhost:11434/api/generate"
    
    # Execution Settings
    DRY_RUN = True  # Set False for real execution
    MAX_ITERATIONS = 50  # Maximum agent iterations
    TERMINAL_TIMEOUT = 900  # Command timeout (seconds)
    
    # Workspace
    BASE_WORKSPACE = Path.cwd().resolve()
    
    # UI Colors
    THEME_COLOR = "cyan"
    ERROR_COLOR = "red"
    SUCCESS_COLOR = "green"
```

### Important Settings

- **DRY_RUN**: When `True`, shows commands without executing (safe testing)
- **MAX_ITERATIONS**: Prevents infinite loops
- **MODEL**: Optimized Qwen3 4B model with Q5_K_M quantization for best performance

---

## 📁 Directory Structure

The agent creates an organized workspace:

```
engagements/
└── example.com/
    ├── metadata.json           # Engagement metadata
    ├── recon/                  # Reconnaissance outputs
    │   ├── nmap_scan.txt
    │   ├── subdomains.txt
    │   └── whois.txt
    ├── enum/                   # Enumeration data
    │   ├── gobuster.txt
    │   ├── nikto.txt
    │   └── httpx.txt
    ├── exploits/               # Exploitation artifacts
    │   ├── sqlmap/
    │   └── generated_exploit.py
    ├── reports/                # Final reports
    │   └── engagement_report_20240115.md
    ├── loot/                   # Collected data
    └── screenshots/            # Evidence screenshots
```

---

## 🛠️ Available Tools

The agent has access to 50+ Kali Linux tools:

### Reconnaissance
- nmap, masscan, amass, subfinder, dnsenum, whois, theHarvester

### Web Enumeration
- gobuster, ffuf, dirsearch, feroxbuster, nikto, whatweb, wpscan, httpx

### Vulnerability Scanning
- sqlmap, nuclei, wfuzz, commix, xsser

### Exploitation
- metasploit, msfvenom, hydra, medusa

### Password Cracking
- john, hashcat

### Network Analysis
- wireshark, tcpdump, netdiscover

### Utilities
- curl, wget, nc, python3, bash, and standard Unix tools

Use the `-h` flag or view the tool reference in the interactive menu.

---

## 📊 Report Generation

The agent automatically generates comprehensive reports:

### Report Sections

1. **Executive Summary**: High-level overview and key findings
2. **Scope**: Target information and engagement parameters
3. **Findings**: Detailed vulnerabilities by severity
4. **Evidence**: Command outputs and screenshots
5. **Remediation**: Actionable fix recommendations
6. **Appendix**: Tool outputs and execution logs

### Sample Report Structure

```markdown
# PENETRATION TESTING REPORT

## EXECUTIVE SUMMARY
Critical: 2 | High: 5 | Medium: 8 | Low: 12

## FINDINGS

### CRITICAL (2)

**1. SQL Injection in Login Form**
- CVSS: 9.8
- Evidence: sqlmap confirmed injection
- Remediation: Use parameterized queries

### HIGH (5)
...
```

---

## 🔒 Security Considerations

### Safe Usage

1. **Authorization Required**: Only test targets you own or have written permission to test
2. **Dry Run First**: Always test with `DRY_RUN = True` before live execution
3. **Scoped Engagement**: Define clear boundaries
4. **Legal Compliance**: Follow all applicable laws and regulations

### Built-in Protections

- ✅ Command allowlisting (only Kali tools)
- ✅ Path traversal prevention
- ✅ Workspace sandboxing
- ✅ Execution logging
- ✅ Authorization confirmations

### Limitations

- **No Warranty**: Use at your own risk
- **Human Oversight**: Always review agent actions
- **Not Autonomous**: Requires monitoring
- **Lab Environment**: Best suited for controlled environments

---

## 🤝 Contributing

Contributions welcome! Areas for improvement:

- [ ] Additional tool integrations
- [ ] Enhanced output parsing
- [ ] More sophisticated finding correlation
- [ ] HTML report templates
- [ ] Screenshot automation
- [ ] Multi-target support
- [ ] Distributed scanning

---

## 📝 License

MIT License - See LICENSE file

---

## 🙏 Acknowledgments

- **Kali Linux Team**: For the comprehensive toolkit
- **Ollama**: For local LLM infrastructure
- **Rich Library**: For beautiful terminal output
- **Security Community**: For methodology and best practices

---

## 📞 Support

- **Issues**: Report bugs via GitHub Issues
- **Discussions**: Share ideas in Discussions
- **Security**: Report vulnerabilities privately

---

## ⚠️ Disclaimer

This tool is for **authorized security testing only**. Unauthorized access to computer systems is illegal. The authors assume no liability for misuse. Always obtain proper authorization before testing.

---

<div align="center">

**Made with ❤️ for the Security Community**

*Stay Legal • Stay Ethical • Stay Safe*

</div>
